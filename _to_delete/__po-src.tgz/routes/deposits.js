const express = require('express');
const https = require('https');
const { pool } = require('../db');
const { requireAuth, requirePermission, withScope } = require('../middleware/auth');
const { logAudit } = require('../utils/audit');

const router = express.Router();

// Seeing every deposit (rather than only your own), exporting, and deleting are
// all gated by the view_all_deposits permission via withScope -> req.scopeAll.

async function generateDepositNumber() {
  const year = new Date().getFullYear();
  const prefix = 'DEP-' + year + '-%';
  const { rows } = await pool.query(
    "SELECT MAX(CAST(SPLIT_PART(deposit_number, '-', 3) AS INTEGER)) as maxseq FROM deposits WHERE deposit_number LIKE $1",
    [prefix]
  );
  const seq = String((rows[0].maxseq || 0) + 1).padStart(4, '0');
  return 'DEP-' + year + '-' + seq;
}

// POST /ai-extract — read a deposit receipt photo and return amount + date.
// The tech reviews/edits the prefilled values before submitting.
router.post('/ai-extract', requireAuth, withScope('view_all_deposits'), requirePermission('create_deposit'), async function(req, res) {
  if (!process.env.ANTHROPIC_API_KEY) return res.status(503).json({ error: 'AI not configured' });
  const { imageData, mediaType } = req.body;
  if (!imageData) return res.status(400).json({ error: 'No image data provided' });

  const prompt = 'You are reading a bank cash deposit receipt or deposit slip. ' +
    'Extract ONLY the following fields and return ONLY valid JSON (no explanation, no markdown):\n' +
    '{\n' +
    '  "amount": 0.00,\n' +
    '  "deposit_date": "YYYY-MM-DD"\n' +
    '}\n' +
    'amount is the total cash/deposit amount as a number with no currency symbol or commas. ' +
    'deposit_date is the date printed on the receipt in YYYY-MM-DD format. ' +
    'If a field is not found, use null.';

  const isPdf = (mediaType || '').toLowerCase() === 'application/pdf';
  const contentBlock = isPdf
    ? { type: 'document', source: { type: 'base64', media_type: 'application/pdf', data: imageData } }
    : { type: 'image', source: { type: 'base64', media_type: mediaType || 'image/jpeg', data: imageData } };

  const body = JSON.stringify({
    model: 'claude-opus-4-8',
    max_tokens: 512,
    messages: [{ role: 'user', content: [ contentBlock, { type: 'text', text: prompt } ] }]
  });

  try {
    const result = await new Promise(function(resolve, reject) {
      var headers = {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
        'Content-Length': Buffer.byteLength(body)
      };
      if (isPdf) headers['anthropic-beta'] = 'pdfs-2024-09-25';
      const options = { hostname: 'api.anthropic.com', path: '/v1/messages', method: 'POST', headers: headers };
      const request = https.request(options, function(r) {
        var data = '';
        r.on('data', function(chunk) { data += chunk; });
        r.on('end', function() { try { resolve(JSON.parse(data)); } catch(e) { reject(e); } });
      });
      request.on('error', reject);
      request.write(body);
      request.end();
    });
    if (result.error) return res.status(500).json({ error: result.error.message });
    const text = (result.content[0].text || '').trim();
    // Extract the JSON object without relying on markdown fences (keeps this file backtick-free)
    const start = text.indexOf('{');
    const end = text.lastIndexOf('}');
    const jsonStr = (start !== -1 && end !== -1) ? text.slice(start, end + 1) : text;
    const extracted = JSON.parse(jsonStr);
    res.json(extracted);
  } catch (err) {
    console.error('Deposit AI extract error:', err);
    res.status(500).json({ error: 'Failed to extract data from image' });
  }
});

// POST / — submit a deposit with optional Pulsar-owed figure, multiple receipt
// photos, and expense lines (each expense may carry its own photo).
router.post('/', requireAuth, withScope('view_all_deposits'), requirePermission('create_deposit'), async function(req, res) {
  const client = await pool.connect();
  try {
    const { amount, deposit_date, period_start, period_end, city_code, notes, pulsar_owed, receipt_image, receipt_filename } = req.body;
    const amt = parseFloat(amount);
    if (isNaN(amt) || amt <= 0) {
      return res.status(400).json({ error: 'A valid deposit amount is required' });
    }
    if (!deposit_date) {
      return res.status(400).json({ error: 'Deposit date is required' });
    }
    if (pulsar_owed === '' || pulsar_owed == null || isNaN(parseFloat(pulsar_owed))) {
      return res.status(400).json({ error: 'Pulsar shows owed amount is required' });
    }
    if (!city_code) {
      return res.status(400).json({ error: 'City is required' });
    }
    const owed = parseFloat(pulsar_owed);
    // Receipt policy: every expense line must carry a photo, or an explicit "no receipt"
    // override with a written reason.  Enforced here so it cannot be bypassed client-side.
    const rawExpenses = Array.isArray(req.body.expenses) ? req.body.expenses : [];
    for (let k = 0; k < rawExpenses.length; k++) {
      const ex = rawExpenses[k];
      if (!ex) continue;
      const exAmtChk = parseFloat(ex.amount);
      const descChk = (ex.description == null ? '' : String(ex.description)).trim();
      if (!descChk && isNaN(exAmtChk)) continue;
      if (!isNaN(exAmtChk) && exAmtChk < 0) {
        return res.status(400).json({ error: 'Expense amount cannot be negative for "' + (descChk || ('expense ' + (k + 1))) + '".' });
      }
      const hasPhoto = !!ex.image;
      const override = ex.no_receipt === true || ex.no_receipt === 'true';
      const reason = (ex.no_receipt_reason == null ? '' : String(ex.no_receipt_reason)).trim();
      const label = descChk || ('expense ' + (k + 1));
      if (!hasPhoto && !override) {
        return res.status(400).json({ error: 'A receipt photo is required for "' + label + '". If you do not have one, check "No receipt" and explain why.' });
      }
      if (!hasPhoto && override && !reason) {
        return res.status(400).json({ error: 'Please explain why there is no receipt for "' + label + '".' });
      }
    }
    // What the AI read off the deposit slip, and whether the tech changed it before submitting.
    const aiAmountRaw = parseFloat(req.body.ai_amount);
    const aiAmount = isNaN(aiAmountRaw) ? null : aiAmountRaw;
    const aiDate = (req.body.ai_deposit_date && /^\d{4}-\d{2}-\d{2}$/.test(String(req.body.ai_deposit_date))) ? String(req.body.ai_deposit_date) : null;
    const amountEdited = aiAmount != null && Math.abs(aiAmount - amt) >= 0.005;
    const dateEdited = aiDate != null && aiDate !== String(deposit_date).slice(0, 10);
    const aiEdited = amountEdited || dateEdited;
    // Duplicate-submission guards.
    const idem = (req.body.idempotency_key == null ? '' : String(req.body.idempotency_key)).slice(0, 64) || null;
    const confirmDuplicate = req.body.confirm_duplicate === true || req.body.confirm_duplicate === 'true';
    const RETURN_COLS = 'id, deposit_number, user_id, user_name, city_code, amount, deposit_date, period_start, period_end, notes, pulsar_owed, ai_amount, ai_deposit_date, ai_edited, created_at';
    // Hard guard: identical idempotency key means the client already submitted this exact request — return the saved row instead of inserting again.
    if (idem) {
      const prior = await pool.query('SELECT ' + RETURN_COLS + ' FROM deposits WHERE idempotency_key = $1', [idem]);
      if (prior.rows.length) { return res.status(200).json(prior.rows[0]); }
    }
    // Soft guard: same person, date, amount and pay period already on file — ask the client to confirm before creating a second one.
    if (!confirmDuplicate) {
      const dupq = await pool.query(
        'SELECT id, deposit_number FROM deposits WHERE user_id = $1 AND deposit_date = $2 AND amount = $3 ' +
        'AND period_start IS NOT DISTINCT FROM $4::date AND city_code IS NOT DISTINCT FROM $5 ' +
        'ORDER BY created_at DESC LIMIT 1',
        [req.user.id, deposit_date, amt, period_start || null, city_code || null]
      );
      if (dupq.rows.length) {
        return res.status(200).json({ duplicate: true, existing_id: dupq.rows[0].id, existing_number: dupq.rows[0].deposit_number });
      }
    }
    // Receipts: prefer the receipts[] array; fall back to the legacy single image.
    let receipts = Array.isArray(req.body.receipts) ? req.body.receipts : [];
    if (!receipts.length && receipt_image) receipts = [{ image: receipt_image, filename: receipt_filename || null }];
    const expenses = rawExpenses;
    let dep = null;
    let expenseTotal = 0;
    var replayed = false;
    for (var attempt = 0; attempt < 10; attempt++) {
    expenseTotal = 0;
    const deposit_number = await generateDepositNumber();
    try {
    await client.query('BEGIN');
    const { rows } = await client.query(
      'INSERT INTO deposits (deposit_number, user_id, user_name, city_code, amount, deposit_date, period_start, period_end, notes, pulsar_owed, idempotency_key, ai_amount, ai_deposit_date, ai_edited) ' +
      'VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14) RETURNING ' + RETURN_COLS,
      [
        deposit_number,
        req.user.id,
        req.user.name,
        city_code || null,
        amt,
        deposit_date,
        period_start || null,
        period_end || null,
        notes || null,
        owed,
        idem,
        aiAmount,
        aiDate,
        aiEdited
      ]
    );
    dep = rows[0];
    for (let i = 0; i < receipts.length; i++) {
      const rc = receipts[i];
      if (rc && rc.image) {
        await client.query(
          'INSERT INTO deposit_receipts (deposit_id, image, filename) VALUES ($1,$2,$3)',
          [dep.id, rc.image, rc.filename || null]
        );
      }
    }
    for (let j = 0; j < expenses.length; j++) {
      const ex = expenses[j];
      if (!ex) continue;
      const exAmt = parseFloat(ex.amount);
      const desc = (ex.description == null ? '' : String(ex.description)).slice(0, 500);
      if (!desc && isNaN(exAmt)) continue;
      const safeAmt = isNaN(exAmt) ? 0 : exAmt;
      expenseTotal += safeAmt;
      const noRc = !ex.image && (ex.no_receipt === true || ex.no_receipt === 'true');
      const noRcReason = noRc ? (ex.no_receipt_reason == null ? '' : String(ex.no_receipt_reason)).trim().slice(0, 1000) : null;
      await client.query(
        'INSERT INTO deposit_expenses (deposit_id, description, amount, receipt_image, receipt_filename, no_receipt, no_receipt_reason) VALUES ($1,$2,$3,$4,$5,$6,$7)',
        [dep.id, desc || null, safeAmt, ex.image || null, ex.filename || null, noRc, noRcReason || null]
      );
    }
    await client.query('COMMIT');
    break;
    } catch (err) {
      try { await client.query('ROLLBACK'); } catch (e) {}
      var isIdemHit = err.code === '23505' && ((err.constraint && err.constraint.indexOf('idempotency') !== -1) || (err.detail && err.detail.indexOf('idempotency_key') !== -1));
      if (isIdemHit && idem) {
        const prior = await pool.query('SELECT ' + RETURN_COLS + ' FROM deposits WHERE idempotency_key = $1', [idem]);
        if (prior.rows.length) { dep = prior.rows[0]; replayed = true; break; }
      }
      if (err.code === '23505' && attempt < 9) continue;
      throw err;
    }
    }
    if (!replayed) {
      await logAudit({
        entity_type: 'deposit',
        entity_id: dep.id,
        entity_number: dep.deposit_number,
        action: 'created',
        user_id: req.user.id,
        user_name: req.user.name,
        details: { amount: amt, pulsar_owed: owed, expense_total: expenseTotal, city_code: city_code || null, ai_amount: aiAmount, ai_deposit_date: aiDate, ai_edited: aiEdited }
      });
    }
    res.status(replayed ? 200 : 201).json(dep);
  } catch (err) {
    try { await client.query('ROLLBACK'); } catch (e) {}
    console.error(err);
    res.status(500).json({ error: 'Failed to submit deposit' });
  } finally {
    client.release();
  }
});

// GET / — list deposits (own for employees; all for see-all roles).
// Includes pulsar_owed and a summed expense total so the client can show Over/Short.
// Never returns receipt images in the list (kept lightweight).
router.get('/', requireAuth, withScope('view_all_deposits'), requirePermission('view_deposits'), async function(req, res) {
  try {
    const cols = 'd.id, d.deposit_number, d.user_id, COALESCE(u.name, d.user_name) AS user_name, d.city_code, d.amount, d.pulsar_owed, d.deposit_date, d.period_start, d.period_end, d.notes, d.receipt_filename, ' +
      'd.ai_amount, d.ai_deposit_date, COALESCE(d.ai_edited, FALSE) AS ai_edited, ' +
      '(d.receipt_image IS NOT NULL OR EXISTS(SELECT 1 FROM deposit_receipts r WHERE r.deposit_id = d.id)) AS has_receipt, ' +
      'COALESCE((SELECT SUM(e.amount) FROM deposit_expenses e WHERE e.deposit_id = d.id), 0) AS total_expenses, ' +
      'EXISTS(SELECT 1 FROM deposit_expenses e2 WHERE e2.deposit_id = d.id AND e2.no_receipt = TRUE) AS has_missing_expense_receipt, ' +
      'd.created_at';
    let query, params;
    if (req.scopeAll) {
      query = 'SELECT ' + cols + ' FROM deposits d LEFT JOIN users u ON u.id = d.user_id ORDER BY d.deposit_date DESC, d.created_at DESC';
      params = [];
    } else {
      query = 'SELECT ' + cols + ' FROM deposits d LEFT JOIN users u ON u.id = d.user_id WHERE d.user_id = $1 ORDER BY d.deposit_date DESC, d.created_at DESC';
      params = [req.user.id];
    }
    const { rows } = await pool.query(query, params);
    res.json(rows);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch deposits' });
  }
});

// GET /export — all deposits for CSV (admin/manager only). No images.
router.get('/export', requireAuth, withScope('view_all_deposits'), requirePermission('export_deposits'), async function(req, res) {
  if (!req.scopeAll) {
    return res.status(403).json({ error: 'Access denied' });
  }
  try {
    const { rows } = await pool.query(
      'SELECT d.deposit_number, COALESCE(u.name, d.user_name) AS user_name, d.city_code, d.amount, d.pulsar_owed, d.deposit_date, d.period_start, d.period_end, d.notes, d.receipt_filename, ' +
      'd.ai_amount, d.ai_deposit_date, COALESCE(d.ai_edited, FALSE) AS ai_edited, ' +
      'EXISTS(SELECT 1 FROM deposit_expenses e2 WHERE e2.deposit_id = d.id AND e2.no_receipt = TRUE) AS has_missing_expense_receipt, ' +
      '(d.receipt_image IS NOT NULL OR EXISTS(SELECT 1 FROM deposit_receipts r WHERE r.deposit_id = d.id)) AS has_receipt, ' +
      'COALESCE((SELECT SUM(e.amount) FROM deposit_expenses e WHERE e.deposit_id = d.id), 0) AS total_expenses, ' +
      'd.created_at FROM deposits d LEFT JOIN users u ON u.id = d.user_id ORDER BY d.deposit_date DESC, d.created_at DESC'
    );
    res.json({ deposits: rows });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to export deposits' });
  }
});

// GET /:id — single deposit incl. receipts and expenses (owner or see-all roles)
router.get('/:id', requireAuth, withScope('view_all_deposits'), requirePermission('view_deposits'), async function(req, res) {
  try {
    const { rows } = await pool.query('SELECT d.*, u.name AS current_user_name FROM deposits d LEFT JOIN users u ON u.id = d.user_id WHERE d.id = $1', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Deposit not found' });
    const dep = rows[0];
    if (dep.current_user_name) dep.user_name = dep.current_user_name;
    delete dep.current_user_name;
    if (!req.scopeAll && dep.user_id !== req.user.id) {
      return res.status(403).json({ error: 'Access denied' });
    }
    const rc = await pool.query('SELECT id, image, filename FROM deposit_receipts WHERE deposit_id = $1 ORDER BY id', [dep.id]);
    dep.receipts = rc.rows;
    // Back-compat: surface the legacy single image as a receipt if no child rows exist.
    if (!dep.receipts.length && dep.receipt_image) {
      dep.receipts = [{ id: null, image: dep.receipt_image, filename: dep.receipt_filename || null }];
    }
    const ex = await pool.query('SELECT id, description, amount, receipt_image, receipt_filename, COALESCE(no_receipt, FALSE) AS no_receipt, no_receipt_reason FROM deposit_expenses WHERE deposit_id = $1 ORDER BY id', [dep.id]);
    dep.expenses = ex.rows;
    res.json(dep);
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to fetch deposit' });
  }
});

// DELETE /:id — admin/manager only. Child receipts/expenses cascade.
router.delete('/:id', requireAuth, withScope('view_all_deposits'), requirePermission('delete_deposit'), async function(req, res) {
  if (!req.scopeAll) {
    return res.status(403).json({ error: 'Access denied' });
  }
  try {
    const { rows } = await pool.query('DELETE FROM deposits WHERE id = $1 RETURNING id, deposit_number', [req.params.id]);
    if (!rows.length) return res.status(404).json({ error: 'Deposit not found' });
    await logAudit({
      entity_type: 'deposit',
      entity_id: rows[0].id,
      entity_number: rows[0].deposit_number,
      action: 'deleted',
      user_id: req.user.id,
      user_name: req.user.name
    });
    res.json({ success: true });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: 'Failed to delete deposit' });
  }
});

module.exports = router;
