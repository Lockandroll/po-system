const express = require('express');
const https = require('https');
const { Pool } = require('pg');
const { pool: novaPool } = require('../db');
const { requireAuth, requireRole, requirePermission } = require('../middleware/auth');

const router = express.Router();

// Load Nova-owned review assignments for a set of Google review_ids.
// Returns a map: review_id -> { assignee, source, user_id, confidence }.
// Never throws — if the table or the main pool is unavailable, callers just
// get an empty map.
async function loadAssignments(ids) {
  const map = {};
  const clean = (ids || []).filter(Boolean);
  if (!clean.length) return map;
  try {
    const { rows } = await novaPool.query(
      'SELECT review_id, assignee, source, user_id, confidence, suggested_user_id FROM review_assignments WHERE review_id = ANY($1)',
      [clean]
    );
    rows.forEach(function (r) { map[r.review_id] = { assignee: r.assignee, source: r.source, user_id: r.user_id, confidence: r.confidence, suggested_user_id: r.suggested_user_id }; });
  } catch (e) {
    console.error('loadAssignments failed:', e.message);
  }
  return map;
}

// Complaints already filed against these Google reviews. Low-star reviews are
// auto-filed into Customer Feedback by jobs/reviewComplaints.js, keyed on
// external_ref = Google's stable review_id. Never throws.
async function loadComplaints(ids) {
  const map = {};
  const clean = (ids || []).filter(Boolean).map(String);
  if (!clean.length) return map;
  try {
    const { rows } = await novaPool.query(
      "SELECT external_ref, id, status FROM customer_feedback WHERE source = 'google_review' AND external_ref = ANY($1)",
      [clean]
    );
    rows.forEach(function (r) { map[r.external_ref] = { id: r.id, status: r.status }; });
  } catch (e) {
    console.error('loadComplaints failed:', e.message);
  }
  return map;
}

// Link text-only assignments (old free-text names or low-confidence guesses)
// to real users whose full name, dispatch (pulsar) name, or nickname exactly
// matches. A bare first name links when every user with that first name has
// the same full name (duplicate accounts of one person; the active account
// wins) — genuinely different people sharing a first name stay unlinked.
// Idempotent; runs at boot (db.js) AND before every tally, so adding a
// nickname takes effect on the next tally run without a redeploy.
async function backfillAssignmentLinks() {
  try {
    await novaPool.query(
      "UPDATE review_assignments ra SET user_id = u.id FROM users u WHERE ra.user_id IS NULL AND TRIM(ra.assignee) <> '' AND (" +
      " LOWER(TRIM(ra.assignee)) = LOWER(TRIM(u.name))" +
      " OR LOWER(TRIM(ra.assignee)) = LOWER(TRIM(COALESCE(u.pulsar_name, '')))" +
      " OR LOWER(TRIM(ra.assignee)) IN (SELECT LOWER(TRIM(x)) FROM unnest(string_to_array(COALESCE(u.nickname, ''), ',')) AS x)" +
      ")"
    );
    await novaPool.query(
      "UPDATE review_assignments ra SET user_id = (" +
      "SELECT u.id FROM users u WHERE LOWER(split_part(TRIM(u.name), ' ', 1)) = LOWER(TRIM(ra.assignee)) " +
      "ORDER BY u.active DESC, u.id DESC LIMIT 1) " +
      "WHERE ra.user_id IS NULL AND TRIM(ra.assignee) <> '' " +
      "AND (SELECT COUNT(DISTINCT LOWER(TRIM(u2.name))) FROM users u2 " +
      "WHERE LOWER(split_part(TRIM(u2.name), ' ', 1)) = LOWER(TRIM(ra.assignee))) = 1"
    );
  } catch (e) { console.error('assignment backfill failed:', e.message); }
}

// ---------------------------------------------------------------------------
// Confirming an AI guess
// ---------------------------------------------------------------------------
// An unmatched guess is a name the AI pulled out of the review text but was not
// confident enough (>= MATCH_MIN) to hard-link to a roster user, so nothing is
// credited. Rather than make a manager open the dropdown and scroll for the
// right person on every one of those rows, the list endpoint resolves each
// guess to at most ONE roster user and hands the UI a ready-to-click Confirm
// target. Resolution order:
//   1. suggested_user_id — the roster person the AI itself picked. The tally
//      records this even below the link threshold, so an 80% "Jesse" still
//      knows WHICH Jesse it meant.
//   2. name match — full name, dispatch (pulsar) name, a nickname, or a bare
//      first name, case-insensitive.
//   3. city tiebreak — when a name matches two or more people (two techs named
//      Jesse), keep only those whose home_city equals the Nova city behind the
//      Google listing the review was left on.
// Anything still ambiguous resolves to null: no Confirm button, dropdown only.
// A one-click button that credits the wrong tech is worse than no button.

// Roster for confirm resolution. Everyone, including former employees — old
// reviews still name them.
async function loadConfirmRoster() {
  try {
    const { rows } = await novaPool.query(
      'SELECT id, name, nickname, pulsar_name, active, home_city FROM users'
    );
    return rows;
  } catch (e) {
    console.error('confirm roster query failed:', e.message);
    return [];
  }
}

// lowercased name/nickname/first-name -> [user, ...]. A key held by two people
// is exactly the ambiguity the city tiebreak exists to settle.
function buildNameIndex(roster) {
  const idx = {};
  function add(key, u) {
    const k = String(key == null ? '' : key).trim().toLowerCase();
    if (!k) return;
    if (!idx[k]) idx[k] = [];
    if (idx[k].indexOf(u) === -1) idx[k].push(u);
  }
  (roster || []).forEach(function (u) {
    const full = String(u.name || '').trim();
    add(full, u);
    add(u.pulsar_name, u);
    String(u.nickname || '').split(',').forEach(function (n) { add(n, u); });
    if (full) add(full.split(/\s+/)[0], u);
  });
  return idx;
}

// Google listing title -> Nova city code, for the distinct titles on a page.
// Memoized per call because there are only ever a handful of listings, and the
// underlying matcher costs a query or three each time.
async function cityCodesForLocations(names) {
  const map = {};
  const distinct = [];
  (names || []).forEach(function (n) {
    const k = String(n == null ? '' : n).trim();
    if (k && distinct.indexOf(k) === -1) distinct.push(k);
  });
  if (!distinct.length) return map;
  let resolveCityForLocation;
  try {
    // Required lazily on purpose: jobs/reviewComplaints.js requires THIS file
    // for the reviews pool, so a top-level require would be a cycle.
    resolveCityForLocation = require('../jobs/reviewComplaints').resolveCityForLocation;
  } catch (e) { return map; }
  if (typeof resolveCityForLocation !== 'function') return map;
  let overrides = {};
  try {
    const s = await novaPool.query("SELECT value FROM settings WHERE key = 'review_city_map'");
    if (s.rows.length && s.rows[0].value) {
      const parsed = JSON.parse(s.rows[0].value);
      if (parsed && typeof parsed === 'object') overrides = parsed;
    }
  } catch (e) { overrides = {}; }
  for (let i = 0; i < distinct.length; i++) {
    try { map[distinct[i]] = await resolveCityForLocation(distinct[i], overrides); }
    catch (e) { map[distinct[i]] = null; }
  }
  return map;
}

// The single roster user a guess may be confirmed to, or null. Never returns a
// user for a row that is already credited.
function resolveConfirmTarget(a, cityCode, nameIdx, byId) {
  if (!a || a.user_id) return null;
  const key = String(a.assignee == null ? '' : a.assignee).trim().toLowerCase();
  const hits = key ? (nameIdx[key] || []) : [];
  const want = cityCode ? String(cityCode).trim().toUpperCase() : '';
  function homeCity(u) { return u.home_city ? String(u.home_city).trim().toUpperCase() : ''; }

  const pick = a.suggested_user_id ? byId[a.suggested_user_id] : null;
  if (pick) {
    // Guard the one trap a sub-threshold pick can walk into: a first name two
    // techs share. If the AI chose the one who is NOT based in the city this
    // review came from while a same-name tech IS based there, the pick and the
    // roster disagree in exactly the way that credits the wrong person. Fail
    // closed and let the dropdown settle it. When the name is unambiguous we do
    // not second-guess the AI on city — techs cover other cities all the time.
    if (hits.length > 1 && want && homeCity(pick) && homeCity(pick) !== want &&
        hits.some(function (u) { return homeCity(u) === want; })) {
      return null;
    }
    return pick;
  }

  if (!key) return null;
  if (hits.length === 1) return hits[0];
  if (hits.length > 1 && want) {
    const inCity = hits.filter(function (u) { return homeCity(u) === want; });
    if (inCity.length === 1) return inCity[0];
  }
  return null;
}

// Resolve confirm targets for a batch of rows. Each row needs review_id and
// location_name; the assignment map supplies the guess. Returns
// review_id -> { id, name } for the rows that resolved to exactly one person.
async function resolveConfirmTargets(rows, amap) {
  const out = {};
  const pending = (rows || []).filter(function (r) {
    const a = r.review_id ? amap[r.review_id] : null;
    return a && a.assignee && !a.user_id;
  });
  if (!pending.length) return out;
  const roster = await loadConfirmRoster();
  if (!roster.length) return out;
  const byId = {};
  roster.forEach(function (u) { byId[u.id] = u; });
  const nameIdx = buildNameIndex(roster);
  const cityMap = await cityCodesForLocations(pending.map(function (r) { return r.location_name; }));
  pending.forEach(function (r) {
    const hit = resolveConfirmTarget(amap[r.review_id], cityMap[String(r.location_name == null ? '' : r.location_name).trim()], nameIdx, byId);
    if (hit) out[r.review_id] = { id: hit.id, name: hit.name };
  });
  return out;
}

// Read-only connection to the Google-review-bot's Postgres, which lives in a
// SEPARATE Railway project. Cross-project means we reach it over its PUBLIC URL
// (set REVIEWS_DATABASE_URL in Nova's Railway variables). Lazy pool so the app
// still boots fine if the variable is not set yet.
let reviewsPool = null;
let reviewsPoolUrl = null;
function getReviewsPool() {
  const url = process.env.REVIEWS_DATABASE_URL;
  if (!url) return null;
  if (reviewsPool && reviewsPoolUrl === url) return reviewsPool;
  if (reviewsPool) { try { reviewsPool.end(); } catch (e) {} }
  reviewsPoolUrl = url;
  // SECURITY: this reaches the review-bot Postgres over its PUBLIC URL, so TLS
  // is doing real work here. Ideally we verify the server cert against a proper
  // CA and set rejectUnauthorized:true. If REVIEWS_DB_CA_CERT (a PEM string) is
  // provided we do exactly that; otherwise we fall back to an unverified TLS
  // session (rejectUnauthorized:false) because Railway's managed Postgres serves
  // a cert that does not chain to the public CA bundle. Internal (.railway.internal)
  // traffic stays on the private network and needs no TLS.
  var reviewsSsl;
  if (url.includes('railway.internal')) {
    reviewsSsl = false;
  } else if (process.env.REVIEWS_DB_CA_CERT) {
    reviewsSsl = { ca: process.env.REVIEWS_DB_CA_CERT, rejectUnauthorized: true };
  } else {
    // TODO: supply REVIEWS_DB_CA_CERT and drop this branch to get real cert
    // verification instead of encryption-only TLS.
    reviewsSsl = { rejectUnauthorized: false };
  }
  reviewsPool = new Pool({
    connectionString: url,
    ssl: reviewsSsl,
    max: 4,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 10000
  });
  reviewsPool.on('error', function (e) { console.error('reviews pool error:', e.message); });
  return reviewsPool;
}

function notConfigured(res) {
  return res.status(503).json({ error: 'Reviews database is not connected yet. Add a REVIEWS_DATABASE_URL variable in Nova’s Railway settings (the review-bot Postgres public URL).' });
}

// Build the shared WHERE clause used by both the list and the AI tally, from a
// plain object of filters (location, rating, search, from, to). Returns
// { whereSql, params } with $1.. placeholders.
function buildReviewFilters(f) {
  const where = [];
  const params = [];
  if (f.location) { params.push(f.location); where.push('location_name = $' + params.length); }
  if (f.rating)   { params.push(parseInt(f.rating, 10)); where.push('rating = $' + params.length); }
  if (f.search)   { params.push('%' + f.search + '%'); where.push('(reviewer_name ILIKE $' + params.length + ' OR review_text ILIKE $' + params.length + ')'); }
  if (f.from)     { params.push(f.from); where.push('review_date >= $' + params.length + '::date'); }
  if (f.to)       { params.push(f.to); where.push("review_date < ($" + params.length + "::date + INTERVAL '1 day')"); }
  return { whereSql: where.length ? ('WHERE ' + where.join(' AND ')) : '', params: params };
}

// GET /api/reviews — filtered list (location, rating, search, from, to)
router.get('/', requireAuth, async (req, res) => {
  const pool = getReviewsPool();
  if (!pool) return notConfigured(res);
  try {
    const { whereSql, params } = buildReviewFilters(req.query);
    const limit = Math.min(parseInt(req.query.limit, 10) || 1000, 5000);
    const cols =
      "id, review_id, location_name, reviewer_name, rating, review_text, reply_text, " +
      "to_char(review_date, 'YYYY-MM-DD') AS review_date, to_char(created_at, 'YYYY-MM-DD') AS created_at";
    const tail = " FROM reviews " + whereSql + " ORDER BY review_date DESC NULLS LAST, id DESC LIMIT " + limit;
    let result;
    try {
      result = await pool.query("SELECT " + cols + tail, params);
    } catch (colErr) {
      // reply_text column may not exist yet (review-bot not deployed) — retry without it
      result = await pool.query("SELECT " + cols.replace('reply_text, ', '') + tail, params);
    }
    // Attach Nova-owned "assigned to" info (kept in a separate database).
    const rows = result.rows;
    const amap = await loadAssignments(rows.map(function (r) { return r.review_id; }));
    rows.forEach(function (r) {
      const a = r.review_id ? amap[r.review_id] : null;
      r.assignee = a ? a.assignee : null;
      r.assignee_source = a ? a.source : null;
      r.assignee_user_id = a ? a.user_id : null;
      r.assignee_confidence = a ? a.confidence : null;
    });
    // One-click Confirm target for each unmatched guess. Rows that are already
    // credited cost nothing here — only the undecided ones are resolved.
    const confirmMap = await resolveConfirmTargets(rows, amap);
    rows.forEach(function (r) {
      const c = r.review_id ? confirmMap[r.review_id] : null;
      r.confirm_user_id = c ? c.id : null;
      r.confirm_user_name = c ? c.name : null;
    });
    // Has this review already been turned into a complaint?
    const cmap = await loadComplaints(rows.map(function (r) { return r.review_id; }));
    rows.forEach(function (r) {
      const c = r.review_id ? cmap[String(r.review_id)] : null;
      r.complaint_id = c ? c.id : null;
      r.complaint_status = c ? c.status : null;
    });
    res.json(rows);
  } catch (err) {
    console.error('GET /api/reviews failed:', err.message);
    res.status(502).json({ error: 'Could not reach the reviews database. Check REVIEWS_DATABASE_URL.' });
  }
});

// GET /api/reviews/stats — global totals + per-location breakdown.
// Prefers Google's OFFICIAL totals (location_totals, written by the review-bot
// from the v4 reviews endpoint's totalReviewCount/averageRating) so the
// dashboard matches the public Google counts exactly. Falls back to a raw row
// count of the logged reviews if those totals are not available yet (e.g. the
// bot has not deployed/run since this feature was added).
router.get('/stats', requireAuth, async (req, res) => {
  const pool = getReviewsPool();
  if (!pool) return notConfigured(res);
  const { whereSql, params } = buildReviewFilters(req.query);
  const hasFilter = !!whereSql;
  try {
    // Per-location aggregates. With NO filter we prefer Google's OFFICIAL totals
    // (location_totals) so the dashboard matches the public Google counts exactly.
    // Once ANY filter is applied (rating/date/search/location), those lifetime
    // totals no longer describe the slice, so we count the matching logged rows.
    let byLoc;
    if (!hasFilter) {
      try {
        byLoc = await pool.query(
          'SELECT r.location_name, ' +
          'COALESCE(lt.total_review_count, r.row_count)::int AS count, ' +
          'COALESCE(lt.average_rating, r.row_avg)::numeric AS avg_rating ' +
          'FROM (SELECT location_name, COUNT(*)::int AS row_count, ' +
          'COALESCE(ROUND(AVG(rating)::numeric, 2), 0) AS row_avg ' +
          'FROM reviews GROUP BY location_name) r ' +
          'LEFT JOIN location_totals lt ON lt.location_name = r.location_name ' +
          'ORDER BY avg_rating DESC, count DESC'
        );
      } catch (joinErr) {
        byLoc = await pool.query(
          'SELECT location_name, COUNT(*)::int AS count, ' +
          'COALESCE(ROUND(AVG(rating)::numeric, 2), 0) AS avg_rating ' +
          'FROM reviews GROUP BY location_name ORDER BY avg_rating DESC, count DESC'
        );
      }
    } else {
      byLoc = await pool.query(
        'SELECT location_name, COUNT(*)::int AS count, ' +
        'COALESCE(ROUND(AVG(rating)::numeric, 2), 0) AS avg_rating ' +
        'FROM reviews ' + whereSql + ' GROUP BY location_name ORDER BY avg_rating DESC, count DESC',
        params
      );
    }

    const fiveStarRes = await pool.query(
      'SELECT COUNT(*) FILTER (WHERE rating = 5)::int AS five_star FROM reviews ' + whereSql,
      params
    );
    const dist = await pool.query(
      'SELECT rating, COUNT(*)::int AS count FROM reviews ' + whereSql + ' GROUP BY rating ORDER BY rating DESC',
      params
    );

    const rows = byLoc.rows;
    let total = 0;
    let weighted = 0;
    rows.forEach(function (r) {
      const c = parseInt(r.count, 10) || 0;
      total += c;
      weighted += c * (parseFloat(r.avg_rating) || 0);
    });
    const avg_rating = total ? Math.round((weighted / total) * 100) / 100 : 0;

    res.json({
      total: total,
      avg_rating: avg_rating,
      five_star: (fiveStarRes.rows[0] || {}).five_star || 0,
      by_location: rows,
      locations: rows.map(function (r) { return r.location_name; }),
      distribution: dist.rows,
      filtered: hasFilter
    });
  } catch (err) {
    console.error('GET /api/reviews/stats failed:', err.message);
    res.status(502).json({ error: 'Could not reach the reviews database. Check REVIEWS_DATABASE_URL.' });
  }
});

// Minimal direct-HTTPS call to Claude (no SDK), mirroring routes/ai.js.
function callClaude(system, userContent, maxTokens) {
  return new Promise(function (resolve, reject) {
    const body = JSON.stringify({
      model: 'claude-opus-4-8',
      max_tokens: maxTokens || 2048,
      system: system,
      messages: [{ role: 'user', content: userContent }]
    });
    const options = {
      hostname: 'api.anthropic.com',
      path: '/v1/messages',
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-api-key': process.env.ANTHROPIC_API_KEY,
        'anthropic-version': '2023-06-01',
        'Content-Length': Buffer.byteLength(body)
      }
    };
    const r = https.request(options, function (resp) {
      let data = '';
      resp.on('data', function (chunk) { data += chunk; });
      resp.on('end', function () {
        try { resolve(JSON.parse(data)); }
        catch (e) { reject(new Error('Failed to parse Anthropic response')); }
      });
    });
    r.on('error', reject);
    r.setTimeout(60000, function () { r.destroy(new Error('AI request timed out. Try a smaller date range.')); });
    r.write(body);
    r.end();
  });
}

// GET /api/reviews/assignees — the people picker for "Assigned To".
// REAL Nova users only (active first; former employees included because older
// reviews still credit them). Every manual assignment must link to a user id —
// unmatched AI guesses are displayed as estimates but are never offered here.
router.get('/assignees', requireAuth, async (req, res) => {
  try {
    const { rows } = await novaPool.query(
      'SELECT id, name, nickname, active FROM users ORDER BY active DESC, name ASC'
    );
    res.json(rows);
  } catch (e) {
    console.error('assignees query failed:', e.message);
    res.json([]);
  }
});

// PUT /api/reviews/assign — manually credit a review to a real Nova user.
// Body: { review_id, user_id }. A null/empty user_id clears the assignment.
// Manual assignments are marked source='manual' and the AI tally never
// overwrites them.
router.put('/assign', requireAuth, requirePermission('assign_reviews'), async (req, res) => {
  const reviewId = (req.body && req.body.review_id != null) ? String(req.body.review_id).trim() : '';
  const userId = parseInt(req.body && req.body.user_id, 10);
  if (!reviewId) return res.status(400).json({ error: 'review_id is required' });
  try {
    if (!userId || isNaN(userId)) {
      await novaPool.query('DELETE FROM review_assignments WHERE review_id = $1', [reviewId]);
      return res.json({ review_id: reviewId, assignee: null, user_id: null, source: null });
    }
    const u = await novaPool.query('SELECT id, name FROM users WHERE id = $1', [userId]);
    if (!u.rows[0]) return res.status(400).json({ error: 'That user does not exist.' });
    await novaPool.query(
      "INSERT INTO review_assignments (review_id, assignee, user_id, suggested_user_id, confidence, source, assigned_by, updated_at) " +
      "VALUES ($1, $2, $3, NULL, NULL, 'manual', $4, NOW()) " +
      "ON CONFLICT (review_id) DO UPDATE SET assignee = EXCLUDED.assignee, user_id = EXCLUDED.user_id, " +
      "suggested_user_id = NULL, confidence = NULL, source = 'manual', assigned_by = EXCLUDED.assigned_by, updated_at = NOW()",
      [reviewId, u.rows[0].name, userId, req.user.id]
    );
    res.json({ review_id: reviewId, assignee: u.rows[0].name, user_id: userId, source: 'manual' });
  } catch (err) {
    console.error('PUT /api/reviews/assign failed:', err.message);
    res.status(500).json({ error: 'Failed to save assignment.' });
  }
});

// POST /api/reviews/confirm-bulk — accept the AI's guess on many reviews at once.
// Body: { review_ids: [...] }. The client says WHICH reviews to confirm; it never
// says WHO to credit. Every id is re-resolved here from scratch (see
// resolveConfirmTarget), so a stale page cannot push through an assignment we
// would not compute ourselves right now, and an id whose guess has since become
// ambiguous is skipped rather than forced. Confirmed rows land as source='manual'
// exactly like a dropdown pick, so a later tally never overwrites them.
router.post('/confirm-bulk', requireAuth, requirePermission('assign_reviews'), async (req, res) => {
  const rpool = getReviewsPool();
  if (!rpool) return notConfigured(res);
  const raw = (req.body && Array.isArray(req.body.review_ids)) ? req.body.review_ids : [];
  const ids = [];
  raw.forEach(function (v) {
    const s = String(v == null ? '' : v).trim();
    if (s && ids.indexOf(s) === -1) ids.push(s);
  });
  if (!ids.length) return res.status(400).json({ error: 'review_ids is required' });
  if (ids.length > 2000) return res.status(400).json({ error: 'Too many reviews in one confirm — narrow the filter first.' });
  try {
    const { rows } = await rpool.query(
      'SELECT review_id, location_name FROM reviews WHERE review_id = ANY($1)',
      [ids]
    );
    const amap = await loadAssignments(rows.map(function (r) { return r.review_id; }));
    const targets = await resolveConfirmTargets(rows, amap);
    const results = [];
    let failed = 0;
    for (let i = 0; i < rows.length; i++) {
      const rid = rows[i].review_id;
      const t = targets[rid];
      if (!t) continue;
      try {
        await novaPool.query(
          "INSERT INTO review_assignments (review_id, assignee, user_id, suggested_user_id, confidence, source, assigned_by, updated_at) " +
          "VALUES ($1, $2, $3, NULL, NULL, 'manual', $4, NOW()) " +
          "ON CONFLICT (review_id) DO UPDATE SET assignee = EXCLUDED.assignee, user_id = EXCLUDED.user_id, " +
          "suggested_user_id = NULL, confidence = NULL, source = 'manual', assigned_by = EXCLUDED.assigned_by, updated_at = NOW()",
          [rid, t.name, t.id, req.user.id]
        );
        results.push({ review_id: rid, user_id: t.id, assignee: t.name });
      } catch (e) {
        failed++;
        console.error('confirm-bulk upsert failed for ' + rid + ':', e.message);
      }
    }
    res.json({
      confirmed: results.length,
      skipped: ids.length - results.length - failed,
      failed: failed,
      results: results
    });
  } catch (err) {
    console.error('POST /api/reviews/confirm-bulk failed:', err.message);
    res.status(500).json({ error: 'Failed to confirm assignments: ' + err.message });
  }
});

// POST /api/reviews/tech-tally — within the same filters as the list
// (location, rating, search, from, to), ask Claude to credit each review to an
// employee. The AI extracts the name from the review text and matches it
// against the REAL user roster (full name, nickname(s), dispatch/pulsar name).
// A match at MATCH_MIN%+ confidence is hard-linked (user_id + canonical name);
// anything weaker is stored as an unmatched guess (user_id NULL) that the UI
// shows as an estimate but never offers as a selectable choice.
router.post('/tech-tally', requireAuth, requireRole('admin'), async (req, res) => {
  const rpool = getReviewsPool();
  if (!rpool) return notConfigured(res);
  if (!process.env.ANTHROPIC_API_KEY) {
    return res.status(503).json({ error: 'AI is not configured (missing ANTHROPIC_API_KEY).' });
  }
  try {
    const { whereSql, params } = buildReviewFilters(req.body || {});
    const FETCH = 1500;     // how many filtered reviews we consider for the counts
    const AICAP = 800;      // how many we will spend AI tokens on in one run
    const CHUNK = 200;      // reviews per AI call (keeps each JSON reply small and parseable)
    const MATCH_MIN = 85;   // % confidence required to hard-link a roster user
    const sql =
      "SELECT review_id, location_name, review_text FROM reviews " + whereSql +
      " ORDER BY review_date DESC NULLS LAST, id DESC LIMIT " + FETCH;
    const { rows } = await rpool.query(sql, params);

    if (rows.length === 0) {
      return res.json({ technicians: [], unnamed: 0, total: 0, analyzed: 0, written: 0, linked: 0, capped: false });
    }

    // Link any text-only names that now exactly match a user (for example a
    // nickname that was just added) before deciding what still needs AI.
    await backfillAssignmentLinks();

    // What is already credited (manual or a prior AI run)?
    const existing = await loadAssignments(rows.map(function (r) { return r.review_id; }));

    // AI candidates: have a stable review_id and are NOT manually assigned
    // (we may refresh our own prior AI guesses, but never touch a manual one).
    // Put the not-yet-assigned ones first so one run maximizes new coverage.
    const candidates = rows.filter(function (r) {
      if (!r.review_id) return false;
      const e = existing[r.review_id];
      return !e || e.source === 'ai';
    }).sort(function (a, b) {
      return (existing[a.review_id] ? 1 : 0) - (existing[b.review_id] ? 1 : 0);
    });
    const aiBatch = candidates.slice(0, AICAP);
    const capped = candidates.length > AICAP;

    let written = 0;
    let linked = 0;
    if (aiBatch.length) {
      // The roster the AI matches against — real Nova users, including former
      // employees (their names still appear on older reviews).
      const rosterRes = await novaPool.query(
        'SELECT id, name, nickname, pulsar_name, active FROM users ORDER BY active DESC, name ASC'
      );
      const rosterById = {};
      rosterRes.rows.forEach(function (u) { rosterById[u.id] = u; });
      const rosterLines = rosterRes.rows.map(function (u) {
        return u.id + ' | ' + (u.name || '-') + (u.active === false ? ' (FORMER employee)' : '') + ' | ' + (u.nickname || '-') + ' | ' + (u.pulsar_name || '-');
      }).join('\n');
      const system =
        'You analyze Google reviews for Pop-A-Lock, a mobile locksmith and roadside ' +
        'company. Below is the employee roster, one person per line, formatted as: ' +
        'id | full name | nickname(s) | dispatch name\n\n' + rosterLines + '\n\n' +
        'For EACH numbered review: extract the single employee name the customer ' +
        'credits for the service (null if no employee is named). Then decide which ' +
        'roster person that name most likely refers to — consider first names, ' +
        'nicknames, dispatch names, and obvious spelling variants; when both a current ' +
        'and a FORMER employee fit equally, prefer the current one — and rate your ' +
        'confidence 0-100 that it is the right person (use null and 0 when nothing ' +
        'plausibly matches). Respond with ONLY raw JSON, no markdown and no ' +
        'backticks, in exactly this shape: {"results":[["Kevin",12,95],[null,null,0]]} ' +
        '— one [extracted_name, roster_id_or_null, confidence] triple per review, in ' +
        'the same order as given.';

      for (let off = 0; off < aiBatch.length; off += CHUNK) {
        const chunk = aiBatch.slice(off, off + CHUNK);
        const list = chunk.map(function (r, i) {
          return (i + 1) + '. ' + ((r.review_text || '').replace(/\s+/g, ' ').trim() || '(no comment)');
        }).join('\n');
        const ai = await callClaude(system, 'Here are ' + chunk.length + ' reviews:\n\n' + list, 8192);
        let text = '';
        try { text = ai.content[0].text; } catch (e) { text = ''; }
        const match = text.match(/\{[\s\S]*\}/);
        let results = [];
        if (match) { try { results = JSON.parse(match[0]).results || []; } catch (e) { results = []; } }
        if (!Array.isArray(results)) results = [];

        // Write each result, but never overwrite a manual assignment.
        for (let i = 0; i < chunk.length; i++) {
          const trip = Array.isArray(results[i]) ? results[i] : [null, null, 0];
          let nm = (typeof trip[0] === 'string') ? trip[0].trim() : '';
          const uid = parseInt(trip[1], 10);
          let conf = parseInt(trip[2], 10);
          if (isNaN(conf)) conf = null; else conf = Math.max(0, Math.min(100, conf));
          const user = (!isNaN(uid) && rosterById[uid]) ? rosterById[uid] : null;
          const isLinked = !!(user && conf != null && conf >= MATCH_MIN);
          if (isLinked) nm = user.name; // store the canonical user name
          if (!nm) continue;            // nobody named — leave unassigned
          try {
            // suggested_user_id keeps the AI's roster pick even when confidence
            // is too low to credit anyone. That is what lets the Reviews page
            // offer "Confirm Jesse Beardshear" on an 80% guess instead of just
            // printing the bare name "Jesse".
            await novaPool.query(
              "INSERT INTO review_assignments (review_id, assignee, user_id, suggested_user_id, confidence, source, updated_at) " +
              "VALUES ($1, $2, $3, $4, $5, 'ai', NOW()) " +
              "ON CONFLICT (review_id) DO UPDATE SET assignee = EXCLUDED.assignee, user_id = EXCLUDED.user_id, " +
              "suggested_user_id = EXCLUDED.suggested_user_id, confidence = EXCLUDED.confidence, source = 'ai', updated_at = NOW() " +
              "WHERE review_assignments.source <> 'manual'",
              [chunk[i].review_id, nm, isLinked ? user.id : null, user ? user.id : null, conf]
            );
            written++;
            if (isLinked) linked++;
            existing[chunk[i].review_id] = { assignee: nm, source: 'ai', user_id: isLinked ? user.id : null, suggested_user_id: user ? user.id : null, confidence: conf };
          } catch (e) { console.error('tally upsert failed:', e.message); }
        }
      }
    }

    // Counts come from the STORED assignments (manual + ai) over the filtered
    // set, so manual fixes and blanks-filled are reflected in the totals.
    // Linked assignments group by user id (canonical name); unmatched guesses
    // group by the raw guessed name and are flagged matched:false.
    const techMap = {};
    let unnamed = 0;
    rows.forEach(function (r) {
      const e = r.review_id ? existing[r.review_id] : null;
      const nm = e && e.assignee ? e.assignee : '';
      if (!nm) { unnamed++; return; }
      const key = (e.user_id ? ('u' + e.user_id) : ('n' + nm.toLowerCase()));
      if (!techMap[key]) techMap[key] = { name: nm, matched: !!e.user_id, count: 0, cities: {} };
      techMap[key].count++;
      const city = r.location_name || '—';
      techMap[key].cities[city] = (techMap[key].cities[city] || 0) + 1;
    });

    const technicians = Object.keys(techMap).map(function (k) {
      const t = techMap[k];
      let topCity = '—', topN = -1;
      Object.keys(t.cities).forEach(function (c) {
        if (t.cities[c] > topN) { topN = t.cities[c]; topCity = c; }
      });
      return { name: t.name, matched: t.matched, location: topCity, multiCity: Object.keys(t.cities).length > 1, count: t.count };
    }).sort(function (a, b) { return b.count - a.count; });

    res.json({
      technicians: technicians,
      unnamed: unnamed,
      total: rows.length,
      analyzed: aiBatch.length,
      written: written,
      linked: linked,
      capped: capped
    });
  } catch (err) {
    console.error('POST /api/reviews/tech-tally failed:', err.message);
    res.status(502).json({ error: 'Tally failed: ' + err.message });
  }
});

// POST /api/reviews/file-complaint - open a Customer Feedback complaint for one
// Google review by hand. Reviews at or below the complaint threshold file
// themselves on a 30-minute cron (jobs/reviewComplaints.js); this is for older
// reviews from before that job was switched on, and for the occasional higher-star
// review that still needs working. The UNIQUE(source, external_ref) index makes a
// double click harmless - it comes back as the existing record.
router.post('/file-complaint', requireAuth, requirePermission('manage_feedback'), async (req, res) => {
  const rpool = getReviewsPool();
  if (!rpool) return notConfigured(res);
  const reviewId = (req.body && req.body.review_id != null) ? String(req.body.review_id).trim() : '';
  if (!reviewId) return res.status(400).json({ error: 'review_id is required' });
  try {
    const { rows } = await rpool.query(
      "SELECT id, review_id, location_name, reviewer_name, rating, review_text, " +
      "to_char(review_date, 'YYYY-MM-DD') AS review_date, created_at " +
      "FROM reviews WHERE review_id = $1 LIMIT 1",
      [reviewId]
    );
    if (!rows.length) return res.status(404).json({ error: 'That review is not in the reviews database.' });
    // Required lazily on purpose: jobs/reviewComplaints.js requires THIS file for
    // the reviews pool, so requiring it at the top would be a cycle.
    const { fileComplaintForReview } = require('../jobs/reviewComplaints');
    const result = await fileComplaintForReview(rows[0]);
    if (!result || !result.id) return res.status(500).json({ error: 'Could not file the complaint. Check the server log.' });
    res.json({ id: result.id, duplicate: !!result.duplicate, review_id: reviewId });
  } catch (err) {
    console.error('POST /api/reviews/file-complaint failed:', err.message);
    res.status(500).json({ error: 'Failed to file complaint: ' + err.message });
  }
});

module.exports = router;
module.exports.getReviewsPool = getReviewsPool;
