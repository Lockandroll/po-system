const express = require('express');
const bcrypt = require('bcryptjs');
const crypto = require('crypto');
const { pool } = require('../db');
const { requireAuth, requireRole, requirePermission } = require('../middleware/auth');
// The invite email moved to utils/invite.js when the New Hires roster grew its
// own Resend button — both routers send the identical message from one place.
const { sendInvite } = require('../utils/invite');
const { logAudit } = require('../utils/audit');
const security = require('../utils/security');

const router = express.Router();

const VALID_ROLES = ['locksmith', 'locksmith_coordinator', 'dispatcher', 'roadside_technician', 'manager', 'admin', 'owner'];

const ROLE_LABELS = {
  locksmith: 'Locksmith',
  locksmith_coordinator: 'Locksmith Coordinator',
  dispatcher: 'Dispatcher',
  roadside_technician: 'Roadside Technician',
  manager: 'Manager',
  admin: 'Admin',
  owner: 'Owner'
};

async function setUserCities(userId, codes) {
  if (!Array.isArray(codes)) return null;
  const clean = Array.from(new Set(codes.map(function (c) { return String(c || '').trim().slice(0, 3); }).filter(Boolean)));
  await pool.query('DELETE FROM user_cities WHERE user_id=$1', [userId]);
  for (const c of clean) await pool.query('INSERT INTO user_cities (user_id, city_code) VALUES ($1,$2) ON CONFLICT (user_id, city_code) DO NOTHING', [userId, c]);
  return clean;
}

// List all users (admin only)
router.get('/', requireAuth, requirePermission('view_users'), async (req, res) => {
  const { rows } = await pool.query(
    'SELECT id, name, email, phone, role, title, active, receive_emails, receive_sms, receive_win_digest, pulsar_name, nickname, hide_from_schedule, hide_from_org, pay_type, employment_type, supervisor_id, org_level, hire_date, home_city, default_backup_id, pto_balance_hours, org_x, extra_perms, created_at, last_login_at, last_seen_at, failed_attempts, lockout_until FROM users ORDER BY active DESC, name ASC'
  );
  const mc = await pool.query('SELECT user_id, city_code FROM user_cities');
  const byU = {};
  mc.rows.forEach(function (r) { (byU[r.user_id] = byU[r.user_id] || []).push((r.city_code || '').trim()); });
  rows.forEach(function (u) { u.city_codes = byU[u.id] || []; });
  res.json(rows);
});

// Per-user grantable permissions. Only these may be set via the user form so the
// checkbox UI can never accidentally elevate someone to manage_users/settings.
const GRANTABLE_PERMS = ['manage_schedule'];
// Employment status. Only full_time accrues PTO. Returns null for anything invalid so
// updates can fall back to the existing value via COALESCE.
const EMPLOYMENT_TYPES = ['full_time', 'part_time', 'contractor'];
function normEmployment(v) { return EMPLOYMENT_TYPES.indexOf(v) !== -1 ? v : null; }
function cleanExtraPerms(v) {
  if (!Array.isArray(v)) return null; // null = caller didn't send it; leave unchanged
  const out = [];
  v.forEach(function (p) { if (GRANTABLE_PERMS.indexOf(p) !== -1 && out.indexOf(p) === -1) out.push(p); });
  return out;
}

// Create user (admin only)
router.post('/', requireAuth, requirePermission('manage_users'), async (req, res) => {
  const { name, email, password, role, phone, receive_emails, receive_sms, receive_win_digest, pulsar_name, nickname, hide_from_schedule, pay_type, employment_type, supervisor_id, title, org_level, hide_from_org, hire_date, home_city, default_backup_id } = req.body;
  if (!name || !email || !role) {
    return res.status(400).json({ error: 'Name, email, and role are required' });
  }
  if (!VALID_ROLES.includes(role)) {
    return res.status(400).json({ error: 'Invalid role. Must be one of: ' + VALID_ROLES.join(', ') + '.' });
  }
  if (role === 'owner' && !req.user.isOwner) {
    const _oc = (await pool.query("SELECT COUNT(*)::int AS n FROM users WHERE role = 'owner' AND active = true")).rows[0].n;
    if (_oc > 0) return res.status(403).json({ error: 'Only an owner can grant the Owner role.' });
  }
  // Password is optional — if none is set, the user picks one via the invite link.
  // A random hash is stored so the account can never be logged into until the invite is used.
  const rawPassword = password || crypto.randomBytes(24).toString('hex');
  const password_hash = await bcrypt.hash(rawPassword, 12);
  try {
    const { rows } = await pool.query(
      'INSERT INTO users (name, email, password_hash, role, phone, receive_emails, receive_sms, receive_win_digest, pulsar_name, nickname, hide_from_schedule, extra_perms, pay_type, employment_type, supervisor_id, title, org_level, hide_from_org, hire_date, home_city, default_backup_id) VALUES ($1, $2, $3, $4, $5, $6, $7, $21, $8, $9, $10, $11, $12, $13, $14, $15, $16, $17, $18, $19, $20) RETURNING id, name, email, phone, role, title, active, receive_emails, receive_sms, receive_win_digest, pulsar_name, nickname, hide_from_schedule, hide_from_org, extra_perms, pay_type, employment_type, supervisor_id, org_level, home_city',
      [name, email, password_hash, role, phone || null, receive_emails !== false, receive_sms === true, pulsar_name || null, nickname || null, hide_from_schedule === true, cleanExtraPerms(req.body.extra_perms) || [], (pay_type || 'hourly'), (normEmployment(employment_type) || 'full_time'), (supervisor_id || null), (title || null), (org_level || null), (hide_from_org === true), (hire_date || null), (home_city || null), (default_backup_id || null), receive_win_digest !== false]
    );
    const newUser = rows[0];
    newUser.city_codes = (await setUserCities(newUser.id, req.body.city_codes)) || [];
    // A newly created admin account is the classic persistence move after a
    // takeover, so account creation is a security event, not just an HR one.
    await security.record(req, {
      event: 'user_created',
      user_id: newUser.id,
      user_name: newUser.name,
      actor: { id: req.user.id, name: req.user.name },
      alert: (newUser.role === 'admin' || newUser.role === 'owner'),
      summary: (req.user.name || 'An admin') + ' created a new ' + (ROLE_LABELS[newUser.role] || newUser.role) + ' account for ' + newUser.name + ' (' + newUser.email + ').',
      details: { email: newUser.email, role: newUser.role }
    });
    try {
      await sendInvite(newUser, req.user && req.user.name);
    } catch (e) {
      console.error('Invite email failed:', e);
    }
    res.status(201).json(newUser);
  } catch (err) {
    if (err.code === '23505') return res.status(400).json({ error: 'Email already in use' });
    throw err;
  }
});

// Create a brand-new hire AND enroll them in onboarding in one step.
router.post('/new-hire', requireAuth, requirePermission('manage_onboarding'), async (req, res) => {
  const { name, email, role, phone } = req.body;
  const supervisor_id = parseInt(req.body && req.body.supervisor_id, 10) || null;
  // Who clears each onboarding phase. Blank = fall back to the supervisor chain.
  const phase1_approver_id = parseInt(req.body && req.body.phase1_approver_id, 10) || null;
  const phase2_approver_id = parseInt(req.body && req.body.phase2_approver_id, 10) || null;
  if (!name || !email || !role) return res.status(400).json({ error: 'Name, email, and role are required' });
  if (!VALID_ROLES.includes(role)) return res.status(400).json({ error: 'Invalid role.' });
  if (role === 'owner') return res.status(400).json({ error: 'Owners are not onboarded.' });
  const rawPassword = crypto.randomBytes(24).toString('hex');
  const password_hash = await bcrypt.hash(rawPassword, 12);
  try {
    const { rows } = await pool.query(
      "INSERT INTO users (name, email, password_hash, role, phone, receive_emails, receive_sms, supervisor_id, onboarding_phase1_approver_id, onboarding_phase2_approver_id, onboarding_status, onboarding_enrolled_at) " +
      "VALUES ($1,$2,$3,$4,$5,true,$6,$7,$8,$9,'required',NOW()) RETURNING id, name, email, role, phone, supervisor_id, onboarding_phase1_approver_id, onboarding_phase2_approver_id",
      [name, email, password_hash, role, phone || null, !!phone, supervisor_id, phase1_approver_id, phase2_approver_id]
    );
    const newUser = rows[0];
    try { await sendInvite(newUser, req.user && req.user.name); } catch (e) { console.error('Invite email failed:', e); }
    await logAudit({ entity_type: 'onboarding', entity_id: newUser.id, action: 'new_hire_created', user_id: req.user.id, user_name: req.user.name, details: { name: name, role: role } });
    res.status(201).json(newUser);
  } catch (err) {
    if (err.code === '23505') return res.status(400).json({ error: 'That email is already in use.' });
    console.error('new-hire create failed:', err.message);
    res.status(500).json({ error: 'Could not create the new hire.' });
  }
});

// Update user (admin only)
router.put('/:id', requireAuth, requirePermission('manage_users'), async (req, res) => {
  const { name, email, role, password, phone, receive_emails, receive_sms, receive_win_digest, pulsar_name, nickname, hide_from_schedule, pay_type, employment_type, supervisor_id, title, org_level, hide_from_org, hire_date, home_city, default_backup_id } = req.body;
  const { id } = req.params;
  if (role && !VALID_ROLES.includes(role)) {
    return res.status(400).json({ error: 'Invalid role. Must be one of: ' + VALID_ROLES.join(', ') + '.' });
  }
  // Read the full "before" picture, not just the role: this is what the audit
  // diff below is built from. Without it a role change left no trace at all.
  const _target = (await pool.query('SELECT id, name, email, role, extra_perms, active FROM users WHERE id=$1', [id])).rows[0];
  if (_target && _target.role === 'owner' && !req.user.isOwner) {
    return res.status(403).json({ error: 'Only an owner can manage owner accounts.' });
  }
  if (role === 'owner' && (!_target || _target.role !== 'owner') && !req.user.isOwner) {
    const _oc = (await pool.query("SELECT COUNT(*)::int AS n FROM users WHERE role = 'owner' AND active = true")).rows[0].n;
    if (_oc > 0) return res.status(403).json({ error: 'Only an owner can grant the Owner role.' });
  }
  let query, params;
  if (password) {
    const password_hash = await bcrypt.hash(password, 12);
    query = 'UPDATE users SET name=COALESCE($1, name), email=COALESCE($2, email), role=COALESCE($3, role), password_hash=$4, phone=$5, receive_emails=$6, receive_sms=$7, receive_win_digest=$22, pulsar_name=$8, nickname=$9, hide_from_schedule=$10, extra_perms=COALESCE($11, extra_perms), pay_type=COALESCE($12, pay_type), supervisor_id=$13, title=$14, org_level=$15, hide_from_org=$16, hire_date=$17, home_city=$18, default_backup_id=$19, employment_type=COALESCE($20, employment_type) WHERE id=$21 RETURNING id, name, email, phone, role, title, active, receive_emails, receive_sms, receive_win_digest, pulsar_name, nickname, hide_from_schedule, hide_from_org, extra_perms, pay_type, employment_type, supervisor_id, org_level, home_city';
    params = [name, email, role, password_hash, phone || null, receive_emails !== false, receive_sms === true, pulsar_name || null, nickname || null, hide_from_schedule === true, cleanExtraPerms(req.body.extra_perms), (pay_type || null), (supervisor_id || null), (title || null), (org_level || null), (hide_from_org === true), (hire_date || null), (home_city || null), (default_backup_id || null), normEmployment(employment_type), id, receive_win_digest !== false];
  } else {
    query = 'UPDATE users SET name=COALESCE($1, name), email=COALESCE($2, email), role=COALESCE($3, role), phone=$4, receive_emails=$5, receive_sms=$6, receive_win_digest=$21, pulsar_name=$7, nickname=$8, hide_from_schedule=$9, extra_perms=COALESCE($10, extra_perms), pay_type=COALESCE($11, pay_type), supervisor_id=$12, title=$13, org_level=$14, hide_from_org=$15, hire_date=$16, home_city=$17, default_backup_id=$18, employment_type=COALESCE($19, employment_type) WHERE id=$20 RETURNING id, name, email, phone, role, title, active, receive_emails, receive_sms, receive_win_digest, pulsar_name, nickname, hide_from_schedule, hide_from_org, extra_perms, pay_type, employment_type, supervisor_id, org_level, home_city';
    params = [name, email, role, phone || null, receive_emails !== false, receive_sms === true, pulsar_name || null, nickname || null, hide_from_schedule === true, cleanExtraPerms(req.body.extra_perms), (pay_type || null), (supervisor_id || null), (title || null), (org_level || null), (hide_from_org === true), (hire_date || null), (home_city || null), (default_backup_id || null), normEmployment(employment_type), id, receive_win_digest !== false];
  }
  // A tech's equipment follows the tech. Read the old home city first so the
  // move can be detected after the update.
  const _prevCity = (await pool.query('SELECT home_city FROM users WHERE id=$1', [id])).rows[0];
  try {
    const { rows } = await pool.query(query, params);
    if (!rows[0]) return res.status(404).json({ error: 'User not found' });
    const _cc = await setUserCities(rows[0].id, req.body.city_codes);
    if (_cc) rows[0].city_codes = _cc;
    // Audit the security-relevant fields only. Editing someone's nickname or
    // phone is routine; changing what they can DO is not, and that distinction
    // is what keeps this log readable enough to actually be checked.
    await auditPrivilegeDiff(req, _target, rows[0], { passwordSet: !!password });
    // Automatic, but never silent: this writes a real transfer record and tells
    // both city managers. Never allowed to fail the user save.
    const _oldCity = _prevCity && _prevCity.home_city ? String(_prevCity.home_city).trim().toUpperCase() : null;
    const _newCity = rows[0].home_city ? String(rows[0].home_city).trim().toUpperCase() : null;
    if (_newCity && _newCity !== _oldCity) {
      relocateAssetsForUser(rows[0].id, _newCity, req.user).catch(function (e) {
        console.error('asset relocation after home_city change failed:', e && e.message);
      });
    }
    res.json(rows[0]);
  } catch (err) {
    if (err.code === '23505') return res.status(400).json({ error: 'Email already in use' });
    throw err;
  }
});

// Compare the security-relevant fields before and after a user save and write
// ONE audit row if any of them moved. Password changes are reported as a fact
// ("password was set by an admin") and never with any part of the value.
// Never throws — an audit failure must not fail the save.
async function auditPrivilegeDiff(req, before, after, opts) {
  try {
    if (!before || !after) return;
    opts = opts || {};
    const changes = {};
    if (before.role !== after.role) changes.role = { from: before.role, to: after.role };
    const bp = (Array.isArray(before.extra_perms) ? before.extra_perms : []).slice().sort();
    const ap = (Array.isArray(after.extra_perms) ? after.extra_perms : []).slice().sort();
    if (bp.join('|') !== ap.join('|')) changes.extra_perms = { from: bp, to: ap };
    if (before.email !== after.email) changes.email = { from: before.email, to: after.email };
    if (before.active !== after.active) changes.active = { from: before.active, to: after.active };
    if (opts.passwordSet) changes.password = 'set by an admin';
    if (!Object.keys(changes).length) return;

    // Escalation to admin or owner is the case worth waking someone up for.
    const escalated = changes.role && (changes.role.to === 'admin' || changes.role.to === 'owner');
    const parts = [];
    if (changes.role) parts.push('role ' + (ROLE_LABELS[changes.role.from] || changes.role.from) + ' -> ' + (ROLE_LABELS[changes.role.to] || changes.role.to));
    if (changes.extra_perms) parts.push('extra permissions now [' + (changes.extra_perms.to.join(', ') || 'none') + ']');
    if (changes.email) parts.push('sign-in email ' + changes.email.from + ' -> ' + changes.email.to);
    if (changes.password) parts.push('password reset by an admin');
    if (changes.active) parts.push(changes.active.to === false ? 'access removed' : 'access restored');

    await security.record(req, {
      event: 'role_changed',
      user_id: after.id || before.id,
      user_name: after.name || before.name,
      actor: { id: req.user && req.user.id, name: req.user && req.user.name },
      alert: true,
      summary: ((req.user && req.user.name) || 'An admin') + ' changed ' + (after.name || before.name) + ': ' + parts.join('; ') + '.',
      details: { changes: changes, escalated_to_admin: !!escalated }
    });
  } catch (e) {
    console.error('[users] privilege audit failed:', e && e.message);
  }
}

// Moves every open holding (and the serialized units behind them) to the tech's
// new city, in one transaction, leaving a transfer record behind. Lives here
// rather than in routes/assets.js so the user save stays the single place a
// home city changes.
async function relocateAssetsForUser(userId, toCity, actor) {
  const assets = require('./assets');
  if (!assets || typeof assets.relocateHoldings !== 'function') return;
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const out = await assets.relocateHoldings(client, { user_id: userId, to_city: toCity, actor: actor });
    await client.query('COMMIT');
    if (out && typeof assets.notifyRelocation === 'function') {
      assets.notifyRelocation(userId, out, toCity).catch(function () {});
    }
  } catch (e) {
    await client.query('ROLLBACK').catch(function () {});
    throw e;
  } finally { client.release(); }
}

// Deactivate user (admin only)
router.post('/:id/deactivate', requireAuth, requirePermission('manage_users'), async (req, res) => {
  const { id } = req.params;
  if (parseInt(id) === req.user.id) {
    return res.status(400).json({ error: 'Cannot deactivate your own account' });
  }
  const _t = (await pool.query('SELECT role, name FROM users WHERE id=$1', [id])).rows[0];
  if (_t && _t.role === 'owner' && !req.user.isOwner) return res.status(403).json({ error: 'Only an owner can deactivate an owner account.' });
  const { rows } = await pool.query('UPDATE users SET active=false WHERE id=$1 RETURNING id, name', [id]);
  if (!rows[0]) return res.status(404).json({ error: 'User not found' });
  await security.record(req, {
    event: 'user_deactivated',
    user_id: rows[0].id,
    user_name: rows[0].name,
    actor: { id: req.user.id, name: req.user.name },
    details: { role: _t && _t.role }
  });
  res.json({ success: true });
});

// Reactivate user (admin only)
router.post('/:id/reactivate', requireAuth, requirePermission('manage_users'), async (req, res) => {
  const { id } = req.params;
  const { rows } = await pool.query('UPDATE users SET active=true WHERE id=$1 RETURNING id, name, role', [id]);
  if (!rows[0]) return res.status(404).json({ error: 'User not found' });
  // Restoring access to a dormant account is a favourite persistence trick, so
  // unlike deactivation this one alerts.
  await security.record(req, {
    event: 'user_reactivated',
    user_id: rows[0].id,
    user_name: rows[0].name,
    actor: { id: req.user.id, name: req.user.name },
    summary: (req.user.name || 'An admin') + ' restored Nova access for ' + rows[0].name + ' (' + (ROLE_LABELS[rows[0].role] || rows[0].role) + ').',
    details: { role: rows[0].role }
  });
  res.json({ success: true });
});

// ---- Account remediation ---------------------------------------------------
// Until 2026-08 there was no way for an admin to clear a lockout or to sign
// somebody out. A locked-out employee had to wait 15 minutes or run a password
// reset, and a compromised session could not be cut off at all short of
// deactivating the whole account.

// Clear a lockout (admin only). Does NOT change the password.
router.post('/:id/unlock', requireAuth, requirePermission('manage_users'), async (req, res) => {
  const { id } = req.params;
  const { rows } = await pool.query(
    'UPDATE users SET failed_attempts=0, lockout_until=NULL WHERE id=$1 RETURNING id, name, failed_attempts',
    [id]
  );
  if (!rows[0]) return res.status(404).json({ error: 'User not found' });
  await security.record(req, {
    event: 'admin_unlocked_account',
    user_id: rows[0].id,
    user_name: rows[0].name,
    actor: { id: req.user.id, name: req.user.name },
    details: { note: 'lockout cleared manually' }
  });
  res.json({ success: true });
});

// Force sign-out everywhere (admin only). Bumps session_epoch, which every
// authenticated request checks in middleware/auth.js, so live JWTs die on their
// very next call. Also drops remembered devices (otherwise the person signs
// straight back in with no 2FA) and revokes OAuth refresh tokens (otherwise a
// connected app keeps minting access tokens for up to 60 days).
// Deliberately does NOT touch the password: cutting off sessions and locking
// someone out of their account are different decisions.
router.post('/:id/signout', requireAuth, requirePermission('manage_users'), async (req, res) => {
  const { id } = req.params;
  const _t = (await pool.query('SELECT id, name, role FROM users WHERE id=$1', [id])).rows[0];
  if (!_t) return res.status(404).json({ error: 'User not found' });
  if (_t.role === 'owner' && !req.user.isOwner) {
    return res.status(403).json({ error: 'Only an owner can sign out an owner account.' });
  }
  await pool.query('UPDATE users SET session_epoch = COALESCE(session_epoch,0) + 1 WHERE id=$1', [id]);
  let devices = 0, tokens = 0;
  try { devices = (await pool.query('DELETE FROM trusted_devices WHERE user_id=$1', [id])).rowCount || 0; }
  catch (e) { console.error('signout: trusted device purge failed:', e.message); }
  try { tokens = (await pool.query('UPDATE oauth_refresh_tokens SET revoked = true WHERE user_id = $1 AND revoked = false', [id])).rowCount || 0; }
  catch (e) { console.error('signout: oauth revoke failed:', e.message); }
  await security.record(req, {
    event: 'admin_forced_signout',
    user_id: _t.id,
    user_name: _t.name,
    actor: { id: req.user.id, name: req.user.name },
    details: { trusted_devices_removed: devices, oauth_tokens_revoked: tokens }
  });
  res.json({ success: true, trusted_devices_removed: devices, oauth_tokens_revoked: tokens });
});

// Delete user (admin only — only if no POs)
router.delete('/:id', requireAuth, requirePermission('manage_users'), async (req, res) => {
  const { id } = req.params;
  if (parseInt(id) === req.user.id) {
    return res.status(400).json({ error: 'Cannot delete your own account' });
  }
  const _t2 = (await pool.query('SELECT role, name, email FROM users WHERE id=$1', [id])).rows[0];
  if (_t2 && _t2.role === 'owner' && !req.user.isOwner) return res.status(403).json({ error: 'Only an owner can delete an owner account.' });
  const { rows: poRows } = await pool.query('SELECT COUNT(*) FROM purchase_orders WHERE requester_id=$1', [id]);
  if (parseInt(poRows[0].count) > 0) {
    return res.status(400).json({ error: 'Cannot delete user — they have existing purchase orders. Deactivate instead.' });
  }
  try {
    await pool.query('DELETE FROM users WHERE id = $1', [id]);
  } catch (err) {
    if (err.code === '23503') {
      return res.status(400).json({ error: 'Cannot delete user — they have related records (quotes, repairs, deposits, etc.). Deactivate instead.' });
    }
    throw err;
  }
  // The user row is gone, so entity_id points at an id that no longer resolves.
  // The name and email in details are the only remaining record of who it was.
  await security.record(req, {
    event: 'user_deleted',
    user_id: parseInt(id, 10) || null,
    user_name: _t2 && _t2.name,
    actor: { id: req.user.id, name: req.user.name },
    summary: (req.user.name || 'An admin') + ' permanently deleted the Nova account for ' + ((_t2 && _t2.name) || 'user #' + id) + ((_t2 && _t2.email) ? ' (' + _t2.email + ')' : '') + '.',
    details: { deleted_name: _t2 && _t2.name, deleted_email: _t2 && _t2.email, deleted_role: _t2 && _t2.role }
  });
  res.json({ success: true });
});

// Lightweight re-parent for the drag-and-drop org chart: updates ONLY the
// reporting line + level, nothing else on the user.
router.patch('/:id/org', requireAuth, requirePermission('manage_users'), async (req, res) => {
  const id = parseInt(req.params.id, 10);
  const sets = [], vals = []; let i = 1;
  if (Object.prototype.hasOwnProperty.call(req.body, 'supervisor_id')) {
    let s = req.body.supervisor_id;
    s = (s === null || s === undefined || s === '') ? null : parseInt(s, 10);
    if (s === id) return res.status(400).json({ error: 'A person cannot report to themselves.' });
    sets.push('supervisor_id=$' + (i++)); vals.push(s);
  }
  if (Object.prototype.hasOwnProperty.call(req.body, 'org_level')) {
    let l = req.body.org_level;
    l = (l === null || l === undefined || l === '') ? null : parseInt(l, 10);
    sets.push('org_level=$' + (i++)); vals.push(l);
  }
  if (Object.prototype.hasOwnProperty.call(req.body, 'org_x')) {
    let x = req.body.org_x;
    x = (x === null || x === undefined || x === '') ? null : Math.round(parseFloat(x));
    sets.push('org_x=$' + (i++)); vals.push(x);
  }
  if (!sets.length) return res.json({ ok: true });
  vals.push(id);
  const { rows } = await pool.query('UPDATE users SET ' + sets.join(', ') + ' WHERE id=$' + i + ' RETURNING id', vals);
  if (!rows.length) return res.status(404).json({ error: 'User not found.' });
  res.json({ ok: true });
});

// ---- Bulk CSV import: create or update users, matched by email --------------
router.post('/import', requireAuth, requirePermission('manage_users'), async (req, res) => {
  const rows = Array.isArray(req.body && req.body.rows) ? req.body.rows : null;
  if (!rows || !rows.length) return res.status(400).json({ error: 'No rows to import' });
  const HRS = 8;
  const norm = function (v) { return (v === undefined || v === null) ? '' : String(v).trim(); };
  const asBool = function (v, dflt) { const s = norm(v).toLowerCase(); if (s === '') return dflt; return (s === 'true' || s === 'yes' || s === '1' || s === 'y'); };
  const allUsers = (await pool.query('SELECT id, LOWER(email) AS email, role FROM users')).rows;
  const emailToId = {}; allUsers.forEach(function (u) { emailToId[u.email] = u.id; });
  // Role BEFORE the import, so the audit row below can say exactly which people
  // this CSV moved between roles. A bulk import can rewrite every role in the
  // company in one request and used to leave no trace whatsoever.
  const roleBefore = {}; allUsers.forEach(function (u) { roleBefore[u.email] = u.role; });

  let created = 0, updated = 0; const errors = [];
  const roleChanges = [];
  const createdAccounts = [];
  for (let idx = 0; idx < rows.length; idx++) {
    const r = rows[idx] || {};
    const email = norm(r.email).toLowerCase();
    const name = norm(r.name);
    if (!email) { errors.push({ row: idx + 1, error: 'Missing email' }); continue; }
    try {
      const role = norm(r.role).toLowerCase();
      if (role && !VALID_ROLES.includes(role)) { errors.push({ row: idx + 1, email: email, error: 'Invalid role: ' + role }); continue; }
      const pay_type = ['hourly', 'salary', 'commission'].indexOf(norm(r.pay_type).toLowerCase()) !== -1 ? norm(r.pay_type).toLowerCase() : null;
      const phone = norm(r.phone) || null;
      const title = norm(r.title) || null;
      const org_level = norm(r.org_level) ? (parseInt(r.org_level, 10) || null) : null;
      const hire_date = /^\d{4}-\d{2}-\d{2}$/.test(norm(r.hire_date)) ? norm(r.hire_date) : null;
      const supEmail = norm(r.supervisor_email).toLowerCase();
      const supervisor_id = supEmail ? (emailToId[supEmail] || null) : null;
      if (supEmail && !supervisor_id) errors.push({ row: idx + 1, email: email, error: 'Supervisor not found: ' + supEmail + ' (left blank)' });
      const balRaw = norm(r.pto_balance_days);
      const setBal = balRaw !== '' && !isNaN(Number(balRaw));
      const recvE = asBool(r.receive_emails, true);
      const recvS = asBool(r.receive_sms, false);

      let userId = emailToId[email];
      if (userId) {
        const sets = ['email = $1']; const vals = [email]; let p = 2;
        if (name) { sets.push('name = $' + p); vals.push(name); p++; }
        if (role) { sets.push('role = $' + p); vals.push(role); p++; }
        if (phone !== null) { sets.push('phone = $' + p); vals.push(phone); p++; }
        if (title !== null) { sets.push('title = $' + p); vals.push(title); p++; }
        if (pay_type) { sets.push('pay_type = $' + p); vals.push(pay_type); p++; }
        if (org_level !== null) { sets.push('org_level = $' + p); vals.push(org_level); p++; }
        if (hire_date) { sets.push('hire_date = $' + p); vals.push(hire_date); p++; }
        if (supervisor_id) { sets.push('supervisor_id = $' + p); vals.push(supervisor_id); p++; }
        if (norm(r.receive_emails) !== '') { sets.push('receive_emails = $' + p); vals.push(recvE); p++; }
        if (norm(r.receive_sms) !== '') { sets.push('receive_sms = $' + p); vals.push(recvS); p++; }
        vals.push(userId);
        await pool.query('UPDATE users SET ' + sets.join(', ') + ' WHERE id = $' + p, vals);
        if (role && roleBefore[email] && role !== roleBefore[email]) {
          roleChanges.push({ email: email, from: roleBefore[email], to: role });
        }
        updated++;
      } else {
        if (!name) { errors.push({ row: idx + 1, email: email, error: 'New user needs a name' }); continue; }
        const roleFinal = role || 'locksmith';
        if (roleFinal === 'owner') { errors.push({ row: idx + 1, email: email, error: 'Cannot bulk-create an owner' }); continue; }
        const password_hash = await bcrypt.hash(crypto.randomBytes(24).toString('hex'), 12);
        const ins = await pool.query(
          'INSERT INTO users (name, email, password_hash, role, phone, receive_emails, receive_sms, pay_type, supervisor_id, title, org_level, hire_date) ' +
          'VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12) RETURNING id',
          [name, email, password_hash, roleFinal, phone, recvE, recvS, (pay_type || 'hourly'), supervisor_id, title, org_level, hire_date]
        );
        userId = ins.rows[0].id;
        emailToId[email] = userId;
        createdAccounts.push({ email: email, role: roleFinal });
        created++;
      }

      if (norm(r.cities) !== '') { try { await setUserCities(userId, norm(r.cities).split(/[;|]/)); } catch (e) { /* ignore city errors */ } }

      if (setBal) {
        const targetHours = Number(balRaw) * HRS;
        const cur = await pool.query('SELECT COALESCE(pto_balance_hours,0) AS b FROM users WHERE id = $1', [userId]);
        const delta = targetHours - Number(cur.rows[0].b);
        if (delta !== 0) {
          await pool.query(
            'INSERT INTO pto_ledger (user_id, entry_date, kind, amount_hours, description, created_by) ' +
            "VALUES ($1, CURRENT_DATE, 'adjustment', $2, $3, $4)",
            [userId, delta, 'Opening balance set to ' + Number(balRaw) + ' days (CSV import)', req.user.id]
          );
          await pool.query('UPDATE users SET pto_balance_hours = $1 WHERE id = $2', [targetHours, userId]);
        }
      }
    } catch (e) {
      errors.push({ row: idx + 1, email: email, error: e.message });
    }
  }
  const escalations = roleChanges.filter(function (c) { return c.to === 'admin' || c.to === 'owner'; })
    .concat(createdAccounts.filter(function (c) { return c.role === 'admin' || c.role === 'owner'; }));
  await security.record(req, {
    event: 'users_bulk_imported',
    actor: { id: req.user.id, name: req.user.name },
    // Only worth an alert when the CSV actually moved someone's authority.
    alert: !!(roleChanges.length || escalations.length),
    summary: (req.user.name || 'An admin') + ' ran a bulk user import: ' + created + ' created, ' + updated + ' updated, ' +
      roleChanges.length + ' role change(s)' + (escalations.length ? ', including ' + escalations.length + ' to admin/owner' : '') + '.',
    details: { created: created, updated: updated, role_changes: roleChanges, created_accounts: createdAccounts, errors: errors.length }
  });
  res.json({ created: created, updated: updated, errors: errors });
});

// Resend the invite email (set-password link) to a user who has not finished setup.
router.post('/:id/invite', requireAuth, requirePermission('manage_users'), async (req, res) => {
  const { id } = req.params;
  const { rows } = await pool.query('SELECT id, name, email, role, active, last_login_at FROM users WHERE id=$1', [id]);
  const user = rows[0];
  if (!user) return res.status(404).json({ error: 'User not found' });
  if (user.active === false) return res.status(400).json({ error: 'User is deactivated. Reactivate the account before sending an invite.' });
  if (user.last_login_at) return res.status(400).json({ error: 'This user has already set up their account and logged in. Use password reset instead.' });
  var sent = false;
  try {
    sent = await sendInvite(user, req.user && req.user.name);
  } catch (e) {
    console.error('Resend invite failed:', e);
    sent = false;
  }
  // sendEmail() swallows its own errors, so before it started reporting back this
  // handler always answered "sent" even when Resend had rejected the message.
  if (!sent) return res.status(502).json({ error: 'The invite email could not be sent. Check the address on file and try again - the old link may no longer work.' });
  await logAudit({ entity_type: 'user', entity_id: user.id, action: 'invite_resent', user_id: req.user.id, user_name: req.user.name, details: { email: user.email } });
  res.json({ success: true });
});

module.exports = router;
