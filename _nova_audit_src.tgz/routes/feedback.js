const express = require('express');
const { pool } = require('../db');
const { requireAuth, requirePermission } = require('../middleware/auth');
const { logActivity } = require('../utils/feedbackIntake');
const r2 = require('../utils/r2');
const goto = require('../utils/goto');
const permissions = require('../utils/permissions');
const crypto = require('crypto');

const router = express.Router();

const STATUSES = ['new', 'complaint_pending', 'customer_contacted', 'in_progress', 'resolved', 'closed'];

// Inline permission check for the handful of places a route returns MORE when a
// user holds a second permission, rather than refusing outright. Same shape as
// routes/ar.js: role matrix first, then the user's own extra_perms.
async function hasPerm(req, perm) {
  if (!req.user) return false;
  if (req.user.role === 'admin' || req.user.role === 'owner') return true;
  try { if (await permissions.hasPermission(req.user.role, perm)) return true; } catch (e) {}
  const ep = req._userRow && req._userRow.extra_perms;
  return Array.isArray(ep) && ep.indexOf(perm) !== -1;
}
const CLOSED_STATES = ['resolved', 'closed'];

// Non-admins are scoped to feedback for the cities they manage.
async function cityScope(user) {
  if (user.role === 'admin' || user.role === 'owner') return null; // null = no restriction
  try {
    const r = await pool.query('SELECT city_code FROM user_cities WHERE user_id = $1', [user.id]);
    return r.rows.map(function (x) { return x.city_code; });
  } catch (e) { return []; }
}

// Record that someone opened a complaint. Every open is logged - no dedupe.
// Owners are invisible (never logged). Deliberately does NOT touch
// last_interaction_at - a view is not an interaction with the customer.
async function logView(feedbackId, user) {
  try {
    if (!user || user.isOwner || user.role === 'owner') return;
    await pool.query(
      "INSERT INTO customer_feedback_activity (feedback_id, user_id, user_name, type, body) VALUES ($1,$2,$3,'view','viewed this complaint.')",
      [feedbackId, user.id, user.name]
    );
  } catch (e) { console.error('[feedback] logView:', e.message); }
}

// GET /api/feedback - filtered list.
router.get('/', requireAuth, requirePermission('view_feedback'), async function (req, res) {
  try {
    const where = [];
    const params = [];
    function add(clause, val) { params.push(val); where.push(clause.replace('$$', '$' + params.length)); }

    const scope = await cityScope(req.user);
    if (scope !== null) {
      if (!scope.length) return res.json({ feedback: [], total: 0 });
      params.push(scope); where.push('city_code = ANY($' + params.length + ')');
    }
    if (req.query.city) add('city_code = $$', req.query.city);
    if (req.query.category) add('category = $$', req.query.category);
    if (req.query.severity) add('severity = $$', req.query.severity);
    if (req.query.status) add('status = $$', req.query.status);
    if (req.query.tech) add('tech_user_id = $$', parseInt(req.query.tech, 10));
    if (req.query.resolved === 'true') where.push('is_resolved = true');
    if (req.query.resolved === 'false') where.push('is_resolved = false');
    if (req.query.from) add('received_at >= $$', req.query.from);
    if (req.query.to) add('received_at <= $$', req.query.to);
    if (req.query.search) { params.push('%' + req.query.search + '%'); where.push('(customer_name ILIKE $' + params.length + ' OR incident_text ILIKE $' + params.length + ')'); }

    const whereSql = where.length ? ('WHERE ' + where.join(' AND ')) : '';
    const limit = Math.min(parseInt(req.query.limit, 10) || 100, 500);
    const offset = parseInt(req.query.offset, 10) || 0;

    const countRes = await pool.query('SELECT COUNT(*) FROM customer_feedback ' + whereSql, params);
    const listRes = await pool.query(
      'SELECT f.*, u.name AS assigned_name, t.name AS tech_name, c.name AS city_name ' +
      'FROM customer_feedback f ' +
      'LEFT JOIN users u ON u.id = f.assigned_to ' +
      'LEFT JOIN users t ON t.id = f.tech_user_id ' +
      'LEFT JOIN cities c ON c.code = f.city_code ' +
      whereSql + " ORDER BY (CASE WHEN f.status IN ('resolved','closed') THEN 1 ELSE 0 END) ASC, f.last_interaction_at DESC NULLS LAST LIMIT " + limit + ' OFFSET ' + offset,
      params
    );
    res.json({ feedback: listRes.rows, total: parseInt(countRes.rows[0].count, 10) });
  } catch (e) {
    console.error('GET /feedback:', e.message);
    res.status(500).json({ error: 'Failed to load feedback' });
  }
});

// GET /api/feedback/:id - record + activity timeline.
router.get('/:id', requireAuth, requirePermission('view_feedback'), async function (req, res) {
  try {
    const id = parseInt(req.params.id, 10);
    const r = await pool.query(
      'SELECT f.*, u.name AS assigned_name, t.name AS tech_name, c.name AS city_name ' +
      'FROM customer_feedback f ' +
      'LEFT JOIN users u ON u.id = f.assigned_to ' +
      'LEFT JOIN users t ON t.id = f.tech_user_id ' +
      'LEFT JOIN cities c ON c.code = f.city_code WHERE f.id = $1',
      [id]
    );
    if (!r.rows.length) return res.status(404).json({ error: 'Not found' });
    const scope = await cityScope(req.user);
    if (scope !== null && scope.indexOf(r.rows[0].city_code) === -1) {
      return res.status(403).json({ error: 'Not in your cities' });
    }
    // Don't log views made while an admin is previewing as another user.
    if (!req.viewingAs) await logView(id, req.user);
    // View rows are admin/owner-only. Managers and below never see who opened a record
    // (they can't tell views are being tracked at all). Owner is coerced to 'admin' upstream.
    const seesViews = req.user.role === 'admin';
    const acts = await pool.query(
      'SELECT * FROM customer_feedback_activity WHERE feedback_id = $1' +
      (seesViews ? '' : " AND type <> 'view'") +
      ' ORDER BY created_at DESC',
      [id]
    );
    const atts = await pool.query("SELECT id, file_name, mime_type, size_bytes, uploaded_by_name, created_at FROM customer_feedback_attachments WHERE feedback_id = $1 AND status = 'ready' ORDER BY created_at DESC", [id]);
    // Releases of liability raised from this complaint. Read straight from
    // release_forms rather than a column on this row, so deleting a draft
    // release never leaves a dangling reference here. Empty array for anyone
    // without view_releases, which is how the card stays hidden for them.
    let releases = [];
    if (await hasPerm(req, 'view_releases')) {
      const rl = await pool.query(
        'SELECT id, release_number, status, settlement_amount, claimant_name, rep_name, sent_at, completed_at ' +
        'FROM release_forms WHERE feedback_id = $1 ORDER BY created_at DESC', [id]
      );
      releases = rl.rows;
    }
    res.json({ feedback: r.rows[0], activity: acts.rows, attachments: atts.rows, releases: releases, storageReady: r2.configured() });
  } catch (e) {
    console.error('GET /feedback/:id:', e.message);
    res.status(500).json({ error: 'Failed to load record' });
  }
});

// PATCH /api/feedback/:id - update lifecycle fields with the closing gate.
router.patch('/:id', requireAuth, requirePermission('manage_feedback'), async function (req, res) {
  try {
    const id = parseInt(req.params.id, 10);
    const cur = await pool.query('SELECT * FROM customer_feedback WHERE id = $1', [id]);
    if (!cur.rows.length) return res.status(404).json({ error: 'Not found' });
    const f = cur.rows[0];
    const scope = await cityScope(req.user);
    if (scope !== null && scope.indexOf(f.city_code) === -1) {
      return res.status(403).json({ error: 'Not in your cities' });
    }
    const b = req.body || {};
    // "No tech to assign" clears any tech + fault; the record can then close without one.
    if (b.no_tech === true) { b.tech_user_id = null; b.tech_at_fault = null; }

    // Resolve the post-update values to validate the closing gate.
    const next = {
      status: b.status !== undefined ? b.status : f.status,
      no_tech: b.no_tech !== undefined ? b.no_tech : f.no_tech,
      tech_user_id: b.tech_user_id !== undefined ? b.tech_user_id : f.tech_user_id,
      tech_at_fault: b.tech_at_fault !== undefined ? b.tech_at_fault : f.tech_at_fault,
      total_damages: b.total_damages !== undefined ? b.total_damages : f.total_damages,
      refunded: b.refunded !== undefined ? b.refunded : f.refunded,
      is_resolved: b.is_resolved !== undefined ? b.is_resolved : f.is_resolved
    };
    const closing = (b.is_resolved === true) || CLOSED_STATES.indexOf(next.status) !== -1;
    if (closing) {
      const missing = [];
      if (!next.no_tech) {
        if (!next.tech_user_id) missing.push('tech');
        if (next.tech_at_fault === null || next.tech_at_fault === undefined) missing.push('tech at fault (yes/no)');
      }
      if (next.total_damages === null || next.total_damages === undefined) missing.push('total damages');
      if (next.refunded === null || next.refunded === undefined) missing.push('refunded');
      if (missing.length) {
        return res.status(400).json({ error: 'Cannot close: set ' + missing.join(', ') + ' first.' });
      }
    }

    const sets = [];
    const params = [];
    const events = [];
    function setField(col, val) { params.push(val); sets.push(col + ' = $' + params.length); }

    if (b.status !== undefined && STATUSES.indexOf(b.status) !== -1 && b.status !== f.status) {
      setField('status', b.status); events.push('changed status to ' + b.status.replace(/_/g, ' '));
    }
    if (b.status_notes !== undefined) setField('status_notes', b.status_notes);
    if (b.no_tech !== undefined && b.no_tech !== f.no_tech) {
      setField('no_tech', b.no_tech); events.push(b.no_tech ? 'marked no tech to assign' : 'cleared no tech to assign');
    }
    if (b.tech_user_id !== undefined && b.tech_user_id !== f.tech_user_id) {
      setField('tech_user_id', b.tech_user_id || null); events.push('updated the assigned tech');
    }
    if (b.tech_at_fault !== undefined && b.tech_at_fault !== f.tech_at_fault) {
      setField('tech_at_fault', b.tech_at_fault); events.push('set tech at fault to ' + (b.tech_at_fault === true ? 'Yes' : b.tech_at_fault === false ? 'No' : 'TBD'));
    }
    if (b.total_damages !== undefined) setField('total_damages', b.total_damages);
    if (b.refunded !== undefined) setField('refunded', b.refunded);
    if (b.refunded_amount !== undefined) setField('refunded_amount', b.refunded_amount);
    if (b.assigned_to !== undefined && b.assigned_to !== f.assigned_to) {
      setField('assigned_to', b.assigned_to || null); events.push('reassigned the record');
    }
    if (b.followup_needed !== undefined) setField('followup_needed', b.followup_needed);
    if (b.followup_at !== undefined) { setField('followup_at', b.followup_at || null); setField('followup_sent_at', null); }
    if (b.followup_notes !== undefined) setField('followup_notes', b.followup_notes);
    if (b.is_resolved !== undefined && b.is_resolved !== f.is_resolved) {
      setField('is_resolved', b.is_resolved);
      if (b.is_resolved) { setField('resolved_at', new Date().toISOString()); events.push('marked the feedback resolved'); }
      else { setField('resolved_at', null); }
    }
    if (b.resolved_notes !== undefined) setField('resolved_notes', b.resolved_notes);

    if (!sets.length) return res.json({ feedback: f, unchanged: true });
    params.push(id);
    const upd = await pool.query('UPDATE customer_feedback SET ' + sets.join(', ') + ', updated_at = NOW(), last_interaction_at = NOW() WHERE id = $' + params.length + ' RETURNING *', params);

    const actor = { id: req.user.id, name: req.user.name };
    for (var i = 0; i < events.length; i++) { await logActivity(id, actor, 'event', events[i] + '.', null); }
    res.json({ feedback: upd.rows[0] });
  } catch (e) {
    console.error('PATCH /feedback/:id:', e.message);
    res.status(500).json({ error: 'Failed to update record' });
  }
});

// POST /api/feedback/:id/calls - someone clicked the customer's phone number.
// Same permission as opening the record (view_feedback): calling the customer is
// not a manage action. Owners are invisible and admin preview-as never logs,
// exactly like logView above. Unlike a view, a call IS an interaction with the
// customer, so it bumps last_interaction_at and is visible to everyone.
router.post('/:id/calls', requireAuth, requirePermission('view_feedback'), async function (req, res) {
  try {
    const id = parseInt(req.params.id, 10);
    const cur = await pool.query('SELECT id, city_code, customer_phone FROM customer_feedback WHERE id = $1', [id]);
    if (!cur.rows.length) return res.status(404).json({ error: 'Not found' });
    const scope = await cityScope(req.user);
    if (scope !== null && scope.indexOf(cur.rows[0].city_code) === -1) {
      return res.status(403).json({ error: 'Not in your cities' });
    }
    if (req.viewingAs) return res.json({ success: true, logged: false });
    if (req.user.isOwner || req.user.role === 'owner') return res.json({ success: true, logged: false });
    const phone = cur.rows[0].customer_phone || '';
    await logActivity(id, { id: req.user.id, name: req.user.name }, 'call',
      'called the customer' + (phone ? ' at ' + phone : '') + '.', 'phone');
    await pool.query('UPDATE customer_feedback SET last_interaction_at = NOW() WHERE id = $1', [id]);
    res.json({ success: true, logged: true });
  } catch (e) {
    console.error('POST /feedback/:id/calls:', e.message);
    res.status(500).json({ error: 'Failed to log call' });
  }
});

// POST /api/feedback/:id/notes - add a manual note to the timeline.
router.post('/:id/notes', requireAuth, requirePermission('manage_feedback'), async function (req, res) {
  try {
    const id = parseInt(req.params.id, 10);
    const body = (req.body && req.body.body || '').trim();
    if (!body) return res.status(400).json({ error: 'Note is empty' });
    const exists = await pool.query('SELECT id, city_code FROM customer_feedback WHERE id = $1', [id]);
    if (!exists.rows.length) return res.status(404).json({ error: 'Not found' });
    const scope = await cityScope(req.user);
    if (scope !== null && scope.indexOf(exists.rows[0].city_code) === -1) {
      return res.status(403).json({ error: 'Not in your cities' });
    }
    await logActivity(id, { id: req.user.id, name: req.user.name }, 'note', body, 'app');
    const acts = await pool.query(
      'SELECT * FROM customer_feedback_activity WHERE feedback_id = $1' +
      (req.user.role === 'admin' ? '' : " AND type <> 'view'") +
      ' ORDER BY created_at DESC',
      [id]
    );
    res.json({ activity: acts.rows });
  } catch (e) {
    console.error('POST /feedback/:id/notes:', e.message);
    res.status(500).json({ error: 'Failed to add note' });
  }
});


// ---- Attachments (bytes live in Cloudflare R2; only metadata lives here) ----
function sanitizeName(s) {
  return String(s || 'file').replace(/[^a-zA-Z0-9._-]+/g, '_').slice(0, 200) || 'file';
}

// Step 1: presigned upload URL (browser uploads bytes straight to R2).
router.post('/:id/attachments/upload-url', requireAuth, requirePermission('manage_feedback'), async function (req, res) {
  try {
    if (!r2.configured()) return res.status(503).json({ error: 'File storage is not configured. Add the R2_* environment variables in Railway.' });
    const id = parseInt(req.params.id, 10);
    const exists = await pool.query('SELECT id, city_code FROM customer_feedback WHERE id = $1', [id]);
    if (!exists.rows.length) return res.status(404).json({ error: 'Not found' });
    const scope = await cityScope(req.user);
    if (scope !== null && scope.indexOf(exists.rows[0].city_code) === -1) {
      return res.status(403).json({ error: 'Not in your cities' });
    }
    const fileName = (req.body && req.body.file_name || '').trim();
    if (!fileName) return res.status(400).json({ error: 'File name is required' });
    const mime = (req.body && req.body.mime_type || 'application/octet-stream').slice(0, 255);
    const key = 'feedback/' + id + '/' + crypto.randomUUID() + '/' + sanitizeName(fileName);
    const ins = await pool.query(
      "INSERT INTO customer_feedback_attachments (feedback_id, r2_key, file_name, mime_type, uploaded_by, uploaded_by_name, status) VALUES ($1,$2,$3,$4,$5,$6,'pending') RETURNING id",
      [id, key, fileName.slice(0, 255), mime, req.user.id, req.user.name]
    );
    const uploadUrl = await r2.presignUpload(key, mime);
    res.json({ attachment_id: ins.rows[0].id, uploadUrl: uploadUrl });
  } catch (e) { console.error('feedback upload-url:', e.message); res.status(500).json({ error: 'Failed to start upload' }); }
});

// Step 2: confirm upload finished; mark ready + record size + timeline note.
router.post('/:id/attachments/:attId/confirm', requireAuth, requirePermission('manage_feedback'), async function (req, res) {
  try {
    const id = parseInt(req.params.id, 10);
    const attId = parseInt(req.params.attId, 10);
    const fb = await pool.query('SELECT city_code FROM customer_feedback WHERE id = $1', [id]);
    if (!fb.rows.length) return res.status(404).json({ error: 'Not found' });
    const scope = await cityScope(req.user);
    if (scope !== null && scope.indexOf(fb.rows[0].city_code) === -1) {
      return res.status(403).json({ error: 'Not in your cities' });
    }
    const ar = await pool.query('SELECT id, file_name FROM customer_feedback_attachments WHERE id = $1 AND feedback_id = $2', [attId, id]);
    if (!ar.rows.length) return res.status(404).json({ error: 'Attachment not found' });
    const size = Math.max(0, parseInt(req.body && req.body.size_bytes, 10) || 0);
    await pool.query("UPDATE customer_feedback_attachments SET size_bytes = $1, status = 'ready' WHERE id = $2", [size, attId]);
    await logActivity(id, { id: req.user.id, name: req.user.name }, 'event', 'attached a file: ' + ar.rows[0].file_name + '.', null);
    res.json({ success: true });
  } catch (e) { console.error('feedback att confirm:', e.message); res.status(500).json({ error: 'Failed to confirm upload' }); }
});

// Presigned download / preview URL.
router.get('/:id/attachments/:attId/url', requireAuth, requirePermission('view_feedback'), async function (req, res) {
  try {
    if (!r2.configured()) return res.status(503).json({ error: 'File storage is not configured.' });
    const id = parseInt(req.params.id, 10);
    const attId = parseInt(req.params.attId, 10);
    const fb = await pool.query('SELECT city_code FROM customer_feedback WHERE id = $1', [id]);
    if (!fb.rows.length) return res.status(404).json({ error: 'Not found' });
    const scope = await cityScope(req.user);
    if (scope !== null && scope.indexOf(fb.rows[0].city_code) === -1) {
      return res.status(403).json({ error: 'Not in your cities' });
    }
    const ar = await pool.query("SELECT r2_key, file_name FROM customer_feedback_attachments WHERE id = $1 AND feedback_id = $2 AND status = 'ready'", [attId, id]);
    if (!ar.rows.length) return res.status(404).json({ error: 'Attachment not found' });
    const url = await r2.presignDownload(ar.rows[0].r2_key, ar.rows[0].file_name, req.query.inline === '1');
    res.json({ url: url });
  } catch (e) { console.error('feedback att url:', e.message); res.status(500).json({ error: 'Failed to generate link' }); }
});

// Delete an attachment (from R2 and the table).
router.delete('/:id/attachments/:attId', requireAuth, requirePermission('manage_feedback'), async function (req, res) {
  try {
    const id = parseInt(req.params.id, 10);
    const attId = parseInt(req.params.attId, 10);
    const fb = await pool.query('SELECT city_code FROM customer_feedback WHERE id = $1', [id]);
    if (!fb.rows.length) return res.status(404).json({ error: 'Not found' });
    const scope = await cityScope(req.user);
    if (scope !== null && scope.indexOf(fb.rows[0].city_code) === -1) {
      return res.status(403).json({ error: 'Not in your cities' });
    }
    const ar = await pool.query('SELECT r2_key, file_name FROM customer_feedback_attachments WHERE id = $1 AND feedback_id = $2', [attId, id]);
    if (!ar.rows.length) return res.status(404).json({ error: 'Attachment not found' });
    try { await r2.deleteObject(ar.rows[0].r2_key); } catch (e) { console.error('R2 delete failed:', e.message); }
    await pool.query('DELETE FROM customer_feedback_attachments WHERE id = $1', [attId]);
    await logActivity(id, { id: req.user.id, name: req.user.name }, 'event', 'removed an attachment: ' + ar.rows[0].file_name + '.', null);
    res.json({ success: true });
  } catch (e) { console.error('feedback att delete:', e.message); res.status(500).json({ error: 'Failed to delete attachment' }); }
});


// ---- Call recordings (GoTo Connect) ----------------------------------------
// The list is DERIVED from the call index by phone number rather than stored as
// explicit links, so it is always current and needs no "refresh" step. The
// feedback_call_recordings table holds only the human overrides on top: which
// call is THE complaint call, and which are irrelevant.

function callRow(r) {
  return {
    call_id: r.id,
    direction: r.direction,
    started_at: r.call_started_at,
    ended_at: r.call_ended_at,
    duration_sec: r.duration_sec,
    number: r.external_number,
    // Which employee handled the call is deliberately NOT returned. Tony's
    // call 2026-07-29: these recordings are for understanding what happened
    // with a CUSTOMER, not for watching staff. 'extension' goes with it -
    // internal_number identifies the handler just as directly as the name
    // does (1000 is Tony, 1064 is Ben), so leaving it in the payload would
    // have undone the change for anyone reading the network tab.
    has_recording: r.has_recording,
    // Was gated on media_url, which never arrives - the recording notification
    // carries only an id. Anything with a recording id is worth attempting.
    retrievable: !!r.recording_id,
    has_transcript: !!r.transcript_id,
    archived: !!r.r2_key,
    is_primary: r.is_primary === true,
    hidden: r.hidden === true,
    note: r.note || null
  };
}

// GET /api/feedback/:id/recordings
// Metadata only. No URLs are issued here - playback is a separate, permissioned
// call, so merely opening a complaint never mints a link to customer audio.
//
// FRESHNESS IS PART OF THE ANSWER. goto_calls is a SNAPSHOT written by a cron
// every 10 minutes, and GoTo publishes a call summary some minutes after the
// call ends. A complaint opened minutes after the call it is about therefore
// reads an index that does not hold that call yet. So the high-water mark of
// the index ships with every response: it is the only way the page can say
// "not yet" instead of "never", and for a manager deciding whether to escalate
// those are opposite conclusions.
//
// Tony, 2026-08-25: the panel said "No calls found for this number in the last
// 90 days" about a call that was sitting in GoTo the whole time, three minutes
// old. It was also not true that anything was filtered to 90 days.

// Load the complaint and apply the city scope. Split out because the refresh
// route needs the same two checks BEFORE it is allowed to spend an upstream
// GoTo call on someone else's city.
async function complaintForCalls(id, req) {
  const fb = await pool.query(
    'SELECT id, city_code, customer_phone, received_at FROM customer_feedback WHERE id = $1', [id]
  );
  if (!fb.rows.length) return { notFound: true };
  const scope = await cityScope(req.user);
  if (scope !== null && scope.indexOf(fb.rows[0].city_code) === -1) return { denied: true };
  return { row: fb.rows[0] };
}

async function recordingsPayload(id, req, row) {
  let canPlay = false;
  try { canPlay = await permissions.hasPermission(req.user.role, 'play_call_recordings'); } catch (e) { canPlay = false; }
  if (!canPlay && req.user.id) {
    const ur = req._userRow;
    if (ur && Array.isArray(ur.extra_perms) && ur.extra_perms.indexOf('play_call_recordings') !== -1) canPlay = true;
  }

  // One pass for the count and both high-water marks.
  //
  // 'indexed' stays in the payload even though nothing new reads it. Nova's
  // service worker is stale-while-revalidate, so the FIRST load after a deploy
  // runs the PREVIOUS app.js against this response. That older bundle branches
  // on !d.indexed and would announce "no calls have been indexed yet" - a worse
  // lie than the one being fixed here. Remove this field only once a forced
  // client_min_version has gone out.
  const idx = await pool.query(
    'SELECT COUNT(*)::int AS n, MAX(call_started_at) AS newest,' +
    ' MAX(last_seen_revision) AS last_sync FROM goto_calls'
  );
  const index = {
    empty: idx.rows[0].n === 0,
    newest: idx.rows[0].newest || null,
    last_sync: idx.rows[0].last_sync || null
  };

  const base = {
    canPlay: canPlay,
    indexed: idx.rows[0].n,
    index: index,
    complaint_at: row.received_at || null,
    storageReady: r2.configured(),
    gotoConnected: goto.configured()
  };

  const digits = goto.normalizeDigits(row.customer_phone);
  if (!digits) {
    base.calls = [];
    base.reason = 'no_phone';
    return base;
  }
  const rows = await pool.query(
    'SELECT c.*, l.is_primary, l.hidden, l.note FROM goto_calls c' +
    ' LEFT JOIN feedback_call_recordings l ON l.call_id = c.id AND l.feedback_id = $1' +
    ' WHERE c.external_digits = $2 ORDER BY c.call_started_at DESC NULLS LAST LIMIT 200',
    [id, digits]
  );
  base.calls = rows.rows.map(callRow);
  base.digits = digits;
  return base;
}

router.get('/:id/recordings', requireAuth, requirePermission('view_feedback'), async function (req, res) {
  try {
    const id = parseInt(req.params.id, 10);
    const c = await complaintForCalls(id, req);
    if (c.notFound) return res.status(404).json({ error: 'Not found' });
    if (c.denied) return res.status(403).json({ error: 'Not in your cities' });
    res.json(await recordingsPayload(id, req, c.row));
  } catch (e) {
    console.error('GET /feedback/:id/recordings:', e.message);
    res.status(500).json({ error: 'Failed to load call recordings' });
  }
});

// POST /api/feedback/:id/recordings/refresh
//
// Pull the recent window from GoTo NOW instead of waiting up to ten minutes for
// the cron. This is deliberately NOT a backfill: the window is small and hard
// bounded so the work always fits inside the life of one HTTP request. A real
// backfill is an admin action with its own background runner and progress
// endpoint, and must not be reachable from a complaint page by anybody who can
// view feedback.
//
// Three guards, in this order:
//   single-flight - two managers clicking at once share ONE upstream sync,
//                   because the window is global and not per complaint
//   cooldown      - a click inside the gap re-reads the table and says so,
//                   rather than hammering GoTo from a page anyone can refresh
//   bounded window- at most 24h back, at most 20 pages (2,000 calls), against
//                   a real day of about 650
const REC_REFRESH_GAP_MS = 45000;
const REC_REFRESH_MAX_PAGES = 20;
let _recRefreshAt = 0;
let _recRefreshFlight = null;

async function runRecordingsSync(sinceMs) {
  const now = Date.now();
  // Never reach further back than a day. A complaint about last month is not
  // something an on-demand sync can rescue, and pretending otherwise would have
  // this route page thousands of calls while a browser sits waiting.
  const floor = now - 24 * 3600000;
  // The upper clamp also guarantees end > start, which syncWindow requires.
  const startMs = Math.min(Math.max(sinceMs, floor), now - 120000);
  const stats = await goto.syncWindow({
    startIso: new Date(startMs).toISOString(),
    endIso: new Date(now).toISOString(),
    maxPages: REC_REFRESH_MAX_PAGES
  });
  // A RECORDING_UPLOADED notification can arrive before its call is indexed.
  // Now that the call may have just landed, attach anything parked waiting.
  let drained = { attached: 0 };
  try { drained = await goto.drainPendingMedia(); } catch (e) { drained = { attached: 0 }; }
  return {
    inserted: stats.inserted || 0,
    updated: stats.updated || 0,
    seen: stats.seen || 0,
    attached: drained.attached || 0
  };
}

router.post('/:id/recordings/refresh', requireAuth, requirePermission('view_feedback'), async function (req, res) {
  try {
    const id = parseInt(req.params.id, 10);
    const c = await complaintForCalls(id, req);
    if (c.notFound) return res.status(404).json({ error: 'Not found' });
    if (c.denied) return res.status(403).json({ error: 'Not in your cities' });

    const refreshed = { ran: false, reason: null, inserted: 0, updated: 0, attached: 0 };

    if (!goto.configured()) {
      refreshed.reason = 'not_configured';
    } else {
      let st = null;
      try { st = await goto.status(); } catch (e) { st = null; }
      if (!st || !st.connected || !st.accountKey) {
        refreshed.reason = 'not_connected';
      } else if (_recRefreshFlight) {
        try {
          const r = await _recRefreshFlight;
          refreshed.ran = true;
          refreshed.reason = 'shared';
          refreshed.inserted = r.inserted;
          refreshed.updated = r.updated;
          refreshed.attached = r.attached;
        } catch (e) { refreshed.reason = 'failed'; }
      } else if (Date.now() - _recRefreshAt < REC_REFRESH_GAP_MS) {
        refreshed.reason = 'cooldown';
      } else {
        // Reach back past when the complaint arrived, so the call it is about
        // is inside the window even though it happened a little earlier.
        const at = c.row.received_at ? Date.parse(c.row.received_at) : NaN;
        const since = (isNaN(at) ? Date.now() : at) - 2 * 3600000;
        _recRefreshFlight = runRecordingsSync(since);
        try {
          const r = await _recRefreshFlight;
          refreshed.ran = true;
          refreshed.inserted = r.inserted;
          refreshed.updated = r.updated;
          refreshed.attached = r.attached;
        } catch (e) {
          console.error('feedback recordings refresh:', e.message);
          refreshed.reason = 'failed';
        } finally {
          _recRefreshAt = Date.now();
          _recRefreshFlight = null;
        }
      }
    }

    // Re-read AFTER the sync so the browser gets the fresh list in the same
    // round trip it used to ask for the refresh.
    const body = await recordingsPayload(id, req, c.row);
    body.refreshed = refreshed;
    res.json(body);
  } catch (e) {
    console.error('POST /feedback/:id/recordings/refresh:', e.message);
    res.status(500).json({ error: 'Failed to refresh call recordings' });
  }
});

// GET /api/feedback/:id/recordings/:callId/play
// Archives the audio into R2 on first use, then issues a 120-second URL. Every
// issue is written to the activity timeline, so there is a record of who
// listened to which customer call and when.
router.get('/:id/recordings/:callId/play', requireAuth, requirePermission('play_call_recordings'), async function (req, res) {
  try {
    const id = parseInt(req.params.id, 10);
    const callId = parseInt(req.params.callId, 10);
    const fb = await pool.query('SELECT id, city_code, customer_phone FROM customer_feedback WHERE id = $1', [id]);
    if (!fb.rows.length) return res.status(404).json({ error: 'Not found' });
    const scope = await cityScope(req.user);
    if (scope !== null && scope.indexOf(fb.rows[0].city_code) === -1) {
      return res.status(403).json({ error: 'Not in your cities' });
    }
    // The call must actually belong to this complaint's phone number. Without
    // this check the endpoint would play ANY indexed recording to anyone who can
    // open ANY complaint.
    const digits = goto.normalizeDigits(fb.rows[0].customer_phone);
    const call = await pool.query('SELECT id, external_digits, call_started_at FROM goto_calls WHERE id = $1', [callId]);
    if (!call.rows.length) return res.status(404).json({ error: 'Call not found' });
    if (!digits || call.rows[0].external_digits !== digits) {
      return res.status(403).json({ error: 'That call is not on this complaint' });
    }

    const play = await goto.playbackUrl(callId);

    if (!req.viewingAs && !(req.user.isOwner || req.user.role === 'owner')) {
      const when = call.rows[0].call_started_at ? new Date(call.rows[0].call_started_at).toISOString().slice(0, 10) : 'an unknown date';
      await logActivity(id, { id: req.user.id, name: req.user.name }, 'event',
        'played a call recording from ' + when + '.', 'phone');
    }
    res.json({ url: play.url, mime: play.mime, bytes: play.bytes });
  } catch (e) {
    console.error('GET /feedback/:id/recordings/:callId/play:', e.message);
    res.status(500).json({ error: e.message });
  }
});

// PATCH /api/feedback/:id/recordings/:callId  { is_primary, hidden, note }
// Stores the human judgement over the derived list.
router.patch('/:id/recordings/:callId', requireAuth, requirePermission('manage_feedback'), async function (req, res) {
  try {
    const id = parseInt(req.params.id, 10);
    const callId = parseInt(req.params.callId, 10);
    const fb = await pool.query('SELECT id, city_code, customer_phone FROM customer_feedback WHERE id = $1', [id]);
    if (!fb.rows.length) return res.status(404).json({ error: 'Not found' });
    const scope = await cityScope(req.user);
    if (scope !== null && scope.indexOf(fb.rows[0].city_code) === -1) {
      return res.status(403).json({ error: 'Not in your cities' });
    }
    const digits = goto.normalizeDigits(fb.rows[0].customer_phone);
    const call = await pool.query('SELECT id, external_digits, call_started_at FROM goto_calls WHERE id = $1', [callId]);
    if (!call.rows.length) return res.status(404).json({ error: 'Call not found' });
    if (!digits || call.rows[0].external_digits !== digits) {
      return res.status(403).json({ error: 'That call is not on this complaint' });
    }

    const b = req.body || {};
    // Only one primary per complaint; the partial unique index enforces it, so
    // clear the old one first rather than letting the insert fail.
    if (b.is_primary === true) {
      await pool.query('UPDATE feedback_call_recordings SET is_primary = false WHERE feedback_id = $1', [id]);
    }
    await pool.query(
      'INSERT INTO feedback_call_recordings (feedback_id, call_id, link_type, linked_by, linked_by_name, is_primary, hidden, note)' +
      " VALUES ($1,$2,'manual',$3,$4,$5,$6,$7)" +
      ' ON CONFLICT (feedback_id, call_id) DO UPDATE SET' +
      '   is_primary = COALESCE($5, feedback_call_recordings.is_primary),' +
      '   hidden = COALESCE($6, feedback_call_recordings.hidden),' +
      '   note = COALESCE($7, feedback_call_recordings.note)',
      [id, callId, req.user.id, req.user.name,
       b.is_primary === undefined ? null : !!b.is_primary,
       b.hidden === undefined ? null : !!b.hidden,
       b.note === undefined ? null : String(b.note).slice(0, 255)]
    );

    if (b.is_primary === true) {
      await logActivity(id, { id: req.user.id, name: req.user.name }, 'event', 'marked a call recording as the complaint call.', null);
    }
    res.json({ success: true });
  } catch (e) {
    console.error('PATCH /feedback/:id/recordings/:callId:', e.message);
    res.status(500).json({ error: 'Failed to update the recording' });
  }
});

module.exports = router;
