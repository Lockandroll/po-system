const crypto = require('crypto');
const { pool } = require('../db');

// Central role-based access control.
// Permissions are stored in settings under key 'role_permissions' as JSON:
//   { "manager": ["view_users", ...], "approver": [...], "requester": [...] }
// The admin role ALWAYS has every permission and cannot be restricted.
// When a role has no configured entry, the DEFAULTS below apply — these mirror
// the app's original hard-coded requireRole behavior, so nothing changes until
// an admin edits the matrix.

var ALL_PERMS = [
  'approve_po',       // approve / reject purchase orders
  'cancel_po',        // cancel purchase orders
  'approve_vr',       // approve / reject vehicle repairs
  'manage_vehicles',  // fleet registry
  'manage_vehicle_docs', // attach vault files (registration / insurance) to vehicles
  'manage_vendors',   // vendors / accounts
  'manage_addresses', // shipping addresses
  'manage_cities',    // cities
  'manage_running',   // monthly requisition (admin list / create-po)
  'manage_geico',     // geico surveys
  'view_users',       // view the user list
  'manage_users',     // add / edit / deactivate / delete users
  'manage_settings',  // company info, AI context, notifications, roles
  'view_audit',       // audit log
  'view_ai_admin',    // AI conversation history / usage
  'view_pos', 'create_po', 'edit_po', 'delete_po', 'submit_po',
  'view_quotes', 'create_quote', 'edit_quote', 'delete_quote', 'push_quote_po',
  'view_vr', 'create_vr', 'edit_vr', 'delete_vr', 'submit_vr',
  'view_deposits', 'create_deposit', 'delete_deposit', 'export_deposits',
  'view_signoffs', 'create_signoff', 'edit_signoff', 'complete_signoff', 'delete_signoff'
];

var EMPLOYEE_PERMS = [
  'view_pos', 'create_po', 'edit_po', 'delete_po', 'submit_po',
  'view_quotes', 'create_quote', 'edit_quote', 'delete_quote', 'push_quote_po',
  'view_vr', 'create_vr', 'edit_vr', 'delete_vr', 'submit_vr',
  'view_deposits', 'create_deposit', 'delete_deposit', 'export_deposits',
  'view_signoffs', 'create_signoff', 'edit_signoff', 'complete_signoff', 'delete_signoff'
];
EMPLOYEE_PERMS.push('view_tasks');
ALL_PERMS.push('view_tasks', 'manage_tasks');
EMPLOYEE_PERMS.push('view_work_orders');
ALL_PERMS.push('view_work_orders', 'manage_work_orders');
EMPLOYEE_PERMS.push('view_schedule');
ALL_PERMS.push('view_schedule', 'manage_schedule');
ALL_PERMS.push('manage_parts');
EMPLOYEE_PERMS.push('view_invoices', 'create_invoice', 'edit_invoice', 'delete_invoice');
ALL_PERMS.push('view_invoices', 'create_invoice', 'edit_invoice', 'delete_invoice', 'manage_invoice_setup');
// Refunds: whoever can write an invoice can ASK for a refund on it; approving
// one is a manager-and-up decision (see routes/refunds.js).
EMPLOYEE_PERMS.push('request_refund');
ALL_PERMS.push('request_refund', 'approve_refund');
ALL_PERMS.push('assign_reviews');  // credit Google reviews to a technician
ALL_PERMS.push('view_vendors');  // accounts: read-only access (credentials hidden)
// Certificates of insurance. Deliberately NOT part of manage_vendors: whoever
// handles the insurance renewal should be able to file certificates without
// being handed every vendor portal password.
ALL_PERMS.push('manage_coi');
ALL_PERMS.push('view_feedback', 'manage_feedback');  // customer feedback module
// Playing a call recording is deliberately its own permission, not part of
// manage_feedback. Seeing that a call exists is administrative; listening to a
// customer's recorded conversation is not, and GoTo itself has no per-department
// scoping on recordings, so this gate is doing the real access control.
ALL_PERMS.push('play_call_recordings');
ALL_PERMS.push('view_signatures', 'manage_signatures');  // e-signature module
EMPLOYEE_PERMS.push('view_signatures');
EMPLOYEE_PERMS.push('view_timeclock');  // punch + own timesheet
ALL_PERMS.push('view_timeclock', 'manage_timeclock');  // time clock module
EMPLOYEE_PERMS.push('view_pto');                        // view + request own PTO
ALL_PERMS.push('view_pto', 'manage_pto');               // time off module
ALL_PERMS.push('view_quiz', 'manage_quiz');             // SOP quiz module
ALL_PERMS.push('view_team_quiz');                       // SOP quiz: scoped team visibility for managers
ALL_PERMS.push('manage_onboarding');                    // new-hire onboarding module
EMPLOYEE_PERMS.push('view_inspections');                // monthly vehicle inspections (own vehicle)
ALL_PERMS.push('view_inspections', 'manage_inspections'); // vehicle inspections module
EMPLOYEE_PERMS.push('view_ptt');                        // PTT radio: own city channels + All Hands
EMPLOYEE_PERMS.push('ptt_direct');                      // person-to-person direct talk
ALL_PERMS.push('view_ptt', 'ptt_all_channels', 'ptt_direct');
ALL_PERMS.push('view_royalty', 'manage_royalty');       // royalty statements module
// Offboarding module: admins manage the whole lifecycle; managers get read-only
// visibility by default. send_exit_form / view_exit_interviews stay admin-only
// (admin is '*') and can be granted to individuals via users.extra_perms.
ALL_PERMS.push('view_offboarding', 'manage_offboarding', 'send_exit_form', 'view_exit_interviews');
// Asset / equipment tracker. Everyone can see their own equipment and ask for a
// replacement; managing the inventory and approving replacements are manager
// decisions. NOTE: this module scopes managers to their OWN cities inside
// routes/assets.js, unlike every other module here.
EMPLOYEE_PERMS.push('view_assets', 'request_asset_replacement');
ALL_PERMS.push('view_assets', 'manage_assets', 'request_asset_replacement', 'approve_asset_replacement');
// Live tech locations. Deliberately NOT an employee permission: a tech does not
// need to see where everyone else is, and handing the whole crew a map of each
// other is a different product than dispatch. Being TRACKED needs no permission,
// it is company policy gated on the time clock (see routes/locations.js).
ALL_PERMS.push('view_tech_locations', 'manage_tech_locations');
// Dispatch board. Deliberately NOT in EMPLOYEE_PERMS and NOT in any role's
// DEFAULTS: this module is piloting, so it is off for everybody until an admin
// ticks the box in Roles & Access, or grants one person via users.extra_perms
// on Edit User. Seeing the board ALSO requires being marked "ready to accept
// calls" (routes/dispatch.js requireBoardAccess) - the permission only decides
// whether the door exists, duty decides whether it is open.
ALL_PERMS.push('view_dispatch', 'manage_dispatch');
// Handing a call to someone else is its own permission on purpose. A lead tech
// often needs to pass a call along without also being able to create calls or
// cancel them, and manage_dispatch is too big a hammer for that.
ALL_PERMS.push('assign_dispatch');
// --- Dispatch Phase 2A/2B -------------------------------------------------
// All of these SHIP DARK for the same reason as the two above: not in
// EMPLOYEE_PERMS, not in any role's DEFAULTS, and db.js does NOT backfill them
// onto the saved matrix. On deploy only admin and owner can reach any of it.
ALL_PERMS.push('manage_service_types');   // the service catalog and its categories
ALL_PERMS.push('manage_dispatch_tags');   // the call-tag list
// Seeing WHO ELSE opened a call is a supervisory fact, not a working one, so it
// is its own permission rather than riding on view_dispatch. Managers get it
// implicitly in routes/dispatch.js; this exists so a lead can be given it
// without also being made a manager.
ALL_PERMS.push('view_call_views');
// Call Search is history, not the live board, so it is gated separately and in
// three widening steps: your own calls, your whole city, then everything.
// search_dispatch_all also carries CSV export, because a full call export is a
// customer list.
ALL_PERMS.push('search_dispatch', 'search_dispatch_city', 'search_dispatch_all');
// Roadside techs see customer names and addresses on the LIVE board - they have
// to knock on the right door. In search and history they do not, and this is
// the permission that says otherwise. Masking is applied in the query, not the
// template, and the CSV export reads the same masked projection.
ALL_PERMS.push('view_customer_pii');
// Time codes: the windows of the week that decide what a service costs and what
// ETA the customer is told, per service, per location. Same permission covers
// the account price exceptions layered on top, because they are one decision.
ALL_PERMS.push('manage_pricing');
// Coverage zones. Separate from pricing because drawing the map of where you
// work and setting what you charge are different jobs, often different people.
ALL_PERMS.push('manage_coverage');
// Sending a quote to a customer is deliberately NOT edit_quote. Building a
// quote and putting a price in front of a customer under the company's name
// are different acts, so they are different permissions. Ships to admin,
// manager and locksmith_coordinator via DEFAULTS - but Nova's role matrix has
// already been saved, so it must ALSO be ticked in Roles & Access to take
// effect for those roles (see the note in nova-adding-a-permission).
ALL_PERMS.push('send_quote');
// Tech pay. Three permissions because they are three different trust levels:
// writing the rate tables, reading everybody's pay, and reading your own.
// view_own_pay is the one a tech eventually gets; it never widens past the
// person asking, and it is enforced in the query rather than the template.
// Pay figures stay out of the board payload for anyone without view_pay_report,
// the same treatment the customer phone number already gets.
ALL_PERMS.push('manage_pay_grades', 'view_pay_report', 'view_own_pay');
// Accounts Receivable. view_ar reads the aging and the ledgers; manage_ar
// records payments, adjustments and import batches. ar_writeoff is separate on
// purpose - writing off a balance is not data entry, it is the line an auditor
// asks about, and it should take a second person's access to do.
ALL_PERMS.push('view_ar', 'manage_ar', 'ar_writeoff');
// Accounts Payable. Ships dark exactly like A/R above: view_ap reads the bills
// list and what is due; manage_ap adds and edits bills, marks them paid, and
// sets the reminder settings. NOT in EMPLOYEE_PERMS and NOT in any role's
// DEFAULTS, and db.js does not backfill it onto the saved matrix - on deploy
// only admin and owner reach Accounts Payable until someone ticks the box in
// Settings -> Roles & Access (or grants one person via users.extra_perms).
ALL_PERMS.push('view_ap', 'manage_ap');
// Editing a cash deposit after it was submitted. Deliberately NOT in
// EMPLOYEE_PERMS: a tech may create (and, per the matrix, delete) their own
// deposit, but correcting the numbers on one already on the books is a
// supervisory act. routes/deposits.js gates it a SECOND time on role AND on the
// editor's assigned cities, so a manager can only fix their own locations.
// Inbound sync (webhooks). Ships dark like A/P above: view_sync reads the
// source list and the event log; manage_sync creates sources, rotates tokens
// and replays events. NOT in EMPLOYEE_PERMS and NOT in any role's DEFAULTS.
// manage_sync in particular is close to admin - the token it hands out is a
// standing write path into Nova from outside - so it should stay with admin
// and owner unless there is a specific reason to widen it.
//
// pulsar_write is the OUTBOUND counterpart and is deliberately not the same
// permission as manage_sync: reading what a partner sent us and changing what
// is on their dispatch board are different privileges. Someone triaging our
// event log has no need to put a technician enroute in someone else's system.
// Also ships dark, also in no role's DEFAULTS.
ALL_PERMS.push('view_sync', 'manage_sync', 'pulsar_write');
ALL_PERMS.push('edit_deposit');
// Submitting a deposit "on behalf of" someone else — the manager fills out the
// form and picks who it is credited to, instead of it always being whoever is
// logged in. Deliberately NOT in EMPLOYEE_PERMS: a tech only ever submits their
// own. routes/deposits.js gates it a SECOND time on the target employee's home
// city, exactly like edit_deposit gates the deposit's own city — a manager can
// only complete deposits for employees in the cities they are assigned to.
ALL_PERMS.push('complete_deposit_for_employee');
// Check-in / check-out on a job. Nova calls the account's phone tree on the
// technician's behalf and, when the tree confirms it, stamps the job.
//
// checkin_job IS in EMPLOYEE_PERMS, unlike most new modules here, and that is
// deliberate rather than an oversight: a check-in a technician cannot fire is
// not a feature. It ships inert anyway, because nothing can be dialled until an
// admin has written and tested a profile for that account.
//
// The other two ship dark in the usual way, in no role's DEFAULTS. Writing a
// phone script decides what Nova says to a customer's system, and forcing a
// check-in asserts somebody was on site when the evidence says otherwise. Both
// belong with admin and owner until there is a specific reason to widen them.
ALL_PERMS.push('checkin_job');
ALL_PERMS.push('manage_ivr_profiles', 'override_checkin');
EMPLOYEE_PERMS.push('checkin_job');

// Employee records - performance documentation, both halves of it.
//
// Every one of these ships DARK: none is in EMPLOYEE_PERMS, none is in any
// role's DEFAULTS, and db.js does not backfill them onto the saved matrix. On
// deploy only admin and owner can reach any of it, which is what Tony asked
// for. Managers get it by ticking the boxes in Roles & Access, at which point
// the city scoping in routes/employeeRecords.js starts doing the real work.
//
// The split is deliberate. Writing a coaching note and issuing a disciplinary
// notice are not the same act and should not be the same permission: a lead
// often needs to document a conversation without also being able to start
// somebody down the ladder. approve_discipline is separate again, because the
// approver is by definition not the person who wrote it.
ALL_PERMS.push(
  'view_employee_records',    // open the records half of Employee Files
  'create_employee_note',     // recognition, coaching notes, performance notes
  'create_disciplinary',      // draft and submit a disciplinary notice
  'approve_discipline',       // approve or send back somebody else's notice
  'manage_employee_records'   // void, delete, edit visibility company-wide
);

// Peer shout-outs. An employee writing recognition about a COWORKER, which no
// other permission in this module can express: create_employee_note is a
// manager's authority over their own people, and canActOn() refuses peers
// outright. submit_shoutout only lets somebody NOMINATE - the shout-out is not
// a record and reaches nobody until an approver who already holds
// create_employee_note for that person approves it. There is deliberately no
// separate approve_shoutout: whoever may write a recognition may release one.
//
// This is the one permission here that is eventually meant for EVERYBODY, but
// it still ships dark like the rest of the module (see the note above). Tick it
// on for the roles that should have it in Settings > Roles & Access; until then
// only admin and owner can send one.
ALL_PERMS.push('submit_shoutout');

// Weekly leaderboards - the two Home-screen cards (top revenue, most batteries
// sold) and the screen that uploads the spreadsheet behind them.
//
// Only the UPLOAD is gated. Reading the cards is requireAuth in
// routes/leaderboard.js and always will be: a board nobody can see is not a
// leaderboard. This ships dark in the usual way - not in EMPLOYEE_PERMS, not in
// any role's DEFAULTS - so on deploy only admin and owner can publish a week
// until Tony ticks the box in Roles & Access.
ALL_PERMS.push('manage_leaderboard');

// Release of Liability - the receipt-of-payment and release sent to a customer
// after Nova pays for damage. view_releases reads them; manage_releases creates,
// sends, reminds and voids. Countersigning is NOT a permission: it is limited to
// the representative named on the form (plus admin/owner), because the signature
// is that person's, not the role's - see routes/releases.js.
//
// Ships dark in the usual way - not in EMPLOYEE_PERMS, not in any role's
// DEFAULTS - so on deploy only admin and owner can send a release until Tony
// ticks the box in Roles & Access.
ALL_PERMS.push('view_releases', 'manage_releases');

var DEFAULTS = {
  admin: '*',
  manager: ['view_users', 'manage_cities', 'manage_geico', 'manage_running', 'manage_vehicles', 'manage_vendors', 'view_vendors', 'manage_addresses', 'approve_vr', 'manage_tasks', 'manage_work_orders', 'manage_schedule', 'manage_parts', 'manage_invoice_setup', 'approve_refund', 'assign_reviews', 'view_feedback', 'manage_feedback', 'manage_signatures', 'manage_timeclock', 'manage_pto', 'view_quiz', 'manage_quiz', 'view_team_quiz', 'manage_onboarding', 'ptt_all_channels', 'view_offboarding', 'play_call_recordings', 'manage_assets', 'approve_asset_replacement', 'edit_deposit', 'complete_deposit_for_employee', 'send_quote', 'manage_coi'].concat(EMPLOYEE_PERMS),
  locksmith: EMPLOYEE_PERMS.slice(),
  locksmith_coordinator: EMPLOYEE_PERMS.concat(['manage_work_orders', 'ptt_all_channels', 'send_quote']),
  dispatcher: EMPLOYEE_PERMS.concat(['manage_work_orders', 'ptt_all_channels']),
  roadside_technician: EMPLOYEE_PERMS.slice()
};

var cache = null;
var cacheValid = false;
var cacheAt = 0;
var TTL_MS = 15000;
// Fingerprint of the currently cached role_permissions matrix. Recomputed only when
// the cache is refreshed (at most once per TTL), not on every permission check.
var cfgRev = '0';

function shortHash(s) {
  return crypto.createHash('sha1').update(String(s)).digest('hex').slice(0, 10);
}

async function getRolePerms() {
  if (cacheValid && (Date.now() - cacheAt) < TTL_MS) return cache;
  try {
    const { rows } = await pool.query("SELECT value FROM settings WHERE key = 'role_permissions'");
    if (rows.length && rows[0].value) {
      const parsed = JSON.parse(rows[0].value);
      if (parsed && typeof parsed === 'object') {
        cache = parsed;
        cacheAt = Date.now();
        cacheValid = true;
        cfgRev = shortHash(rows[0].value);
        return parsed;
      }
    }
    // No valid config — cache the empty result so we don't re-query on every check.
    cache = null;
    cacheAt = Date.now();
    cacheValid = true;
    cfgRev = '0';
    return null;
  } catch (e) {
    console.error('Failed to load role_permissions:', e.message);
    return null;
  }
}

// A short fingerprint of everything the CLIENT's can() depends on for this user:
// their role, their per-user extra_perms, whether they are still active, and the
// global role_permissions matrix. Sent to the browser as X-Perms-Rev on every
// authenticated response. When it changes, the client knows its cached permissions
// are stale and refetches them — no logout or page reload required.
async function permsRev(user) {
  await getRolePerms(); // ensures cfgRev reflects the current matrix
  const role = (user && user.role) || '';
  const ep = (user && Array.isArray(user.extra_perms)) ? user.extra_perms.slice().sort().join('|') : '';
  const active = (user && user.active === false) ? '0' : '1';
  return shortHash(role + '~' + ep + '~' + active + '~' + cfgRev);
}

// Synchronous default check (used as a safe fallback).
function defaultHas(role, perm) {
  if (role === 'admin' || role === 'owner') return true;
  const d = DEFAULTS[role];
  return Array.isArray(d) && d.indexOf(perm) !== -1;
}

// Authoritative async check: admin always allowed; otherwise use the configured
// matrix for that role if present, else fall back to defaults.
async function hasPermission(role, perm) {
  if (role === 'admin' || role === 'owner') return true;
  const cfg = await getRolePerms();
  if (cfg && Array.isArray(cfg[role])) return cfg[role].indexOf(perm) !== -1;
  return defaultHas(role, perm);
}

module.exports = {
  ALL_PERMS: ALL_PERMS,
  DEFAULTS: DEFAULTS,
  getRolePerms: getRolePerms,
  defaultHas: defaultHas,
  hasPermission: hasPermission,
  permsRev: permsRev
};
