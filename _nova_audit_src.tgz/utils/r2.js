// Cloudflare R2 storage helper for the Documents vault.
// R2 speaks the S3 API, so we use the AWS S3 SDK pointed at the R2 endpoint.
// Files are uploaded and downloaded directly between the browser and R2 using
// short-lived presigned URLs - bytes never pass through this server, so there
// is no practical file-size limit and no load on Railway.
const { S3Client, PutObjectCommand, GetObjectCommand, DeleteObjectCommand, HeadObjectCommand } = require('@aws-sdk/client-s3');
const { getSignedUrl } = require('@aws-sdk/s3-request-presigner');

const ACCOUNT_ID = process.env.R2_ACCOUNT_ID;
const ACCESS_KEY = process.env.R2_ACCESS_KEY_ID;
const SECRET_KEY = process.env.R2_SECRET_ACCESS_KEY;
const BUCKET = process.env.R2_BUCKET;

// True only when every required env var is set. Routes check this and return a
// clear error instead of crashing if R2 has not been configured yet.
function configured() {
  return !!(ACCOUNT_ID && ACCESS_KEY && SECRET_KEY && BUCKET);
}

let _client = null;
function client() {
  if (_client) return _client;
  _client = new S3Client({
    region: 'auto',
    endpoint: 'https://' + ACCOUNT_ID + '.r2.cloudflarestorage.com',
    forcePathStyle: true,
    credentials: { accessKeyId: ACCESS_KEY, secretAccessKey: SECRET_KEY }
  });
  return _client;
}

// Presigned URL the browser PUTs the file bytes to. Valid for 10 minutes.
async function presignUpload(key, contentType) {
  const cmd = new PutObjectCommand({
    Bucket: BUCKET,
    Key: key,
    ContentType: contentType || 'application/octet-stream'
  });
  return getSignedUrl(client(), cmd, { expiresIn: 600 });
}

// Presigned URL the browser GETs to download/preview the file. Valid 5 minutes.
// filename drives the Save-As name; inline=true lets PDFs/images preview in-tab.
async function presignDownload(key, filename, inline, expiresIn, contentType) {
  const disp = (inline ? 'inline' : 'attachment') +
    (filename ? '; filename="' + filename.replace(/"/g, '') + '"' : '');
  const cmd = new GetObjectCommand(contentType ? {
    Bucket: BUCKET,
    Key: key,
    ResponseContentDisposition: disp,
    ResponseContentType: contentType
  } : {
    Bucket: BUCKET,
    Key: key,
    ResponseContentDisposition: disp
  });
  return getSignedUrl(client(), cmd, { expiresIn: expiresIn || 300 });
}

// Upload bytes straight from this server (used for AI-signature images and the
// final flattened PDF, which are produced server-side rather than in the browser).
async function putObject(key, body, contentType) {
  await client().send(new PutObjectCommand({ Bucket: BUCKET, Key: key, Body: body, ContentType: contentType || 'application/octet-stream' }));
}

async function getObjectBuffer(key) {
  const res = await client().send(new GetObjectCommand({ Bucket: BUCKET, Key: key }));
  const bytes = await res.Body.transformToByteArray();
  return Buffer.from(bytes);
}

// Does this object actually exist, and how big is it? Used when a client claims
// it uploaded a file: the browser PUTs to R2 directly, so this server never sees
// the bytes and has to ask. Returns null when the object is definitely not there.
// Any OTHER error (network, throttling) is rethrown - callers must not read a
// transient failure as "the file is missing".
async function headObject(key) {
  try {
    const res = await client().send(new HeadObjectCommand({ Bucket: BUCKET, Key: key }));
    return { size: res.ContentLength || 0, contentType: res.ContentType || null };
  } catch (e) {
    const code = (e && (e.name || e.Code)) || '';
    const status = e && e.$metadata && e.$metadata.httpStatusCode;
    if (code === 'NotFound' || code === 'NoSuchKey' || status === 404) return null;
    throw e;
  }
}

async function deleteObject(key) {
  if (!key) return;
  await client().send(new DeleteObjectCommand({ Bucket: BUCKET, Key: key }));
}

module.exports = { configured, presignUpload, presignDownload, getObjectBuffer, putObject, headObject, deleteObject };
